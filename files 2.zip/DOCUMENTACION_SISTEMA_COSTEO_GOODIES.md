# DOCUMENTACIÓN COMPLETA - SISTEMA DE COSTEO GOODIES

## Versión: 1.0
## Fecha: Diciembre 2025
## Desarrollado para: GOODIES S.A.

---

# ÍNDICE

1. [Resumen Ejecutivo](#1-resumen-ejecutivo)
2. [Arquitectura del Sistema](#2-arquitectura-del-sistema)
3. [Instalación y Configuración](#3-instalación-y-configuración)
4. [Estructura de la Base de Datos](#4-estructura-de-la-base-de-datos)
5. [Estructura del Proyecto](#5-estructura-del-proyecto)
6. [API - Endpoints](#6-api---endpoints)
7. [Funcionalidades del Sistema](#7-funcionalidades-del-sistema)
8. [Guía de Uso](#8-guía-de-uso)
9. [Fórmulas y Cálculos](#9-fórmulas-y-cálculos)
10. [Troubleshooting](#10-troubleshooting)
11. [Historial de Sesiones](#11-historial-de-sesiones)
12. [Pendientes y Mejoras Futuras](#12-pendientes-y-mejoras-futuras)

---

# 1. RESUMEN EJECUTIVO

## 1.1 Descripción del Sistema

El Sistema de Costeo GOODIES es una aplicación web diseñada para gestionar el costeo de importaciones de mercadería. Reemplaza el sistema anterior basado en HTML/v80 que presentaba problemas de duplicación de costeos y división incorrecta de artículos.

## 1.2 Objetivos Cumplidos

- ✅ Migración a PostgreSQL como base de datos
- ✅ Backend en Node.js con Express
- ✅ Sistema de autenticación con JWT
- ✅ Carga manual de legajos con 4 tabs
- ✅ Importación de Excel con pre-visualización
- ✅ Cálculos automáticos de costeo
- ✅ Soporte para empresa intermediaria
- ✅ Consulta de último costo por artículo
- ✅ Comparación con costo anterior y diferencia %
- ✅ Exportación a Excel

## 1.3 Tecnologías Utilizadas

| Componente | Tecnología | Versión |
|------------|------------|---------|
| Base de Datos | PostgreSQL | 16 |
| Backend | Node.js | 24.12.0 |
| Framework Backend | Express | 4.21.2 |
| ORM | Sequelize | 6.37.5 |
| Autenticación | JWT | 9.0.2 |
| Encriptación | bcryptjs | 2.4.3 |
| Lectura Excel | xlsx | (última) |
| Upload de Archivos | multer | (última) |
| Frontend | HTML/CSS/JavaScript | - |

---

# 2. ARQUITECTURA DEL SISTEMA

## 2.1 Diagrama de Arquitectura

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│   NAVEGADOR     │────▶│   NODE.JS       │────▶│   POSTGRESQL    │
│   (Frontend)    │     │   (Backend)     │     │   (Base Datos)  │
│                 │◀────│   Puerto 3000   │◀────│   Puerto 5432   │
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

## 2.2 Flujo de Datos

1. Usuario accede via navegador a `http://localhost:3000`
2. Frontend envía peticiones HTTP al backend
3. Backend valida autenticación via JWT
4. Backend procesa petición y consulta/modifica PostgreSQL
5. Backend responde con JSON
6. Frontend renderiza la respuesta

## 2.3 Seguridad

- Contraseñas encriptadas con bcrypt (10 rounds)
- Tokens JWT con expiración de 24 horas
- Rutas protegidas requieren token válido
- Validación de datos en backend

---

# 3. INSTALACIÓN Y CONFIGURACIÓN

## 3.1 Prerrequisitos

- Windows 10/11
- PostgreSQL 16 instalado
- Node.js 24+ instalado
- pgAdmin 4 (para administración de BD)

## 3.2 Configuración de PostgreSQL

```
Host: localhost
Puerto: 5432
Usuario: postgres
Password: postgres123
Base de datos: sistema_costeo
```

## 3.3 Configuración del Proyecto

### Ubicación del proyecto:
```
C:\Users\Admin\Desktop\sistema-costeo-backend\
```

### Archivo .env:
```env
PORT=3000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=sistema_costeo
DB_USER=postgres
DB_PASSWORD=postgres123
JWT_SECRET=goodies_sistema_costeo_secreto_2025
```

## 3.4 Comandos de Inicio

### Iniciar el servidor:
```bash
cd Desktop\sistema-costeo-backend
node server.js
```

### Verificar que está corriendo:
- Abrir navegador: `http://localhost:3000`
- Health check: `http://localhost:3000/health`

### Detener el servidor:
- Presionar `Ctrl+C` en el CMD
- Confirmar con `S` y Enter

## 3.5 Usuarios del Sistema

| Email | Password | Rol | Nombre |
|-------|----------|-----|--------|
| lpardina@goodies.com.ar | admin123 | admin | LUZ PARDINA |
| comercioexterior@goodies.com.ar | COMEX123 | comex | ARIANA |

---

# 4. ESTRUCTURA DE LA BASE DE DATOS

## 4.1 Diagrama Entidad-Relación

```
┌─────────────┐       ┌─────────────┐
│  empresas   │       │  usuarios   │
│─────────────│       │─────────────│
│ id (PK)     │◀──────│ empresa_id  │
│ nombre      │       │ id (PK)     │
│ razon_social│       │ email       │
│ cuit        │       │ password    │
│ activa      │       │ nombre      │
└─────────────┘       │ rol         │
                      └──────┬──────┘
                             │
                             ▼
                      ┌─────────────┐
                      │   costeos   │
                      │─────────────│
                      │ id (PK)     │
                      │ usuario_id  │
                      │ empresa_id  │
                      │ nombre_costeo│
                      │ proveedor   │
                      │ ...         │
                      └──────┬──────┘
                             │
           ┌─────────────────┼─────────────────┐
           │                 │                 │
           ▼                 ▼                 ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│articulos_costeo │ │ gastos_aduana   │ │ gastos_varios   │
│─────────────────│ │─────────────────│ │─────────────────│
│ id (PK)         │ │ id (PK)         │ │ id (PK)         │
│ costeo_id (FK)  │ │ costeo_id (FK)  │ │ costeo_id (FK)  │
│ codigo_goodies  │ │ despachante     │ │ descripcion     │
│ nombre          │ │ ...             │ │ monto           │
│ ...             │ └─────────────────┘ │ ...             │
└─────────────────┘                     └─────────────────┘
```

## 4.2 Tabla: empresas

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | UUID | Clave primaria |
| nombre | VARCHAR(255) | Nombre comercial |
| razon_social | VARCHAR(255) | Razón social |
| cuit | VARCHAR(20) | CUIT |
| activa | BOOLEAN | Estado activo/inactivo |
| created_at | TIMESTAMP | Fecha de creación |
| updated_at | TIMESTAMP | Fecha de actualización |

## 4.3 Tabla: usuarios

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | UUID | Clave primaria |
| email | VARCHAR(255) | Email único |
| password_hash | VARCHAR(255) | Contraseña encriptada |
| nombre | VARCHAR(255) | Nombre del usuario |
| rol | VARCHAR(50) | admin, comex, comercial, contable, visualizador |
| empresa_id | UUID | FK a empresas |
| activo | BOOLEAN | Estado activo/inactivo |
| created_at | TIMESTAMP | Fecha de creación |
| updated_at | TIMESTAMP | Fecha de actualización |

## 4.4 Tabla: costeos

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | UUID | Clave primaria |
| usuario_id | UUID | FK a usuarios |
| empresa_id | UUID | FK a empresas |
| nombre_costeo | VARCHAR(255) | Nombre identificador |
| proveedor | VARCHAR(255) | Proveedor de origen |
| empresa_intermediaria | VARCHAR(255) | Nombre intermediaria (opcional) |
| factura_intermediaria | VARCHAR(100) | Nro factura intermediaria |
| fecha_factura_intermediaria | DATE | Fecha factura intermediaria |
| fecha_vencimiento_intermediaria | DATE | Vencimiento intermediaria |
| factura_nro | VARCHAR(100) | Número de factura |
| fecha_factura | DATE | Fecha de factura |
| fecha_vencimiento_factura | DATE | Fecha de vencimiento |
| fecha_despacho | DATE | Fecha de despacho |
| moneda_principal | VARCHAR(10) | USD, EUR, GBP |
| monto_factura | DECIMAL(15,2) | Monto de la factura |
| tc_usd | DECIMAL(10,4) | Tipo de cambio USD |
| tc_eur | DECIMAL(10,4) | Tipo de cambio EUR |
| tc_gbp | DECIMAL(10,4) | Tipo de cambio GBP |
| tc_ars | DECIMAL(10,4) | Tipo de cambio ARS |
| fob_moneda | VARCHAR(10) | Moneda del FOB |
| fob_monto | DECIMAL(15,2) | Monto FOB |
| flete_moneda | VARCHAR(10) | Moneda del flete |
| flete_monto | DECIMAL(15,2) | Monto flete |
| seguro_moneda | VARCHAR(10) | Moneda del seguro |
| seguro_monto | DECIMAL(15,2) | Monto seguro |
| fob_total_usd | DECIMAL(15,2) | FOB total en USD |
| flete_usd | DECIMAL(15,2) | Flete en USD |
| seguro_usd | DECIMAL(15,2) | Seguro en USD |
| cif_total_usd | DECIMAL(15,2) | CIF total en USD |
| cif_total_ars | DECIMAL(15,2) | CIF total en ARS |
| derechos_total_ars | DECIMAL(15,2) | Derechos totales |
| estadistica_ars | DECIMAL(15,2) | Estadística |
| iva_ars | DECIMAL(15,2) | IVA total |
| impuesto_interno_ars | DECIMAL(15,2) | Impuesto interno |
| total_tributos_ars | DECIMAL(15,2) | Total tributos |
| total_gastos_ars | DECIMAL(15,2) | Total gastos |
| costo_total_ars | DECIMAL(15,2) | Costo total |
| unidades_totales | INTEGER | Cantidad total de unidades |
| costo_unitario_promedio_ars | DECIMAL(15,4) | Costo unitario promedio |
| estado | VARCHAR(50) | borrador, calculado, etc. |
| created_at | TIMESTAMP | Fecha de creación |
| updated_at | TIMESTAMP | Fecha de actualización |

## 4.5 Tabla: articulos_costeo

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | UUID | Clave primaria |
| costeo_id | UUID | FK a costeos |
| codigo_goodies | VARCHAR(50) | Código interno |
| codigo_proveedor | VARCHAR(50) | Código del proveedor |
| nombre | VARCHAR(255) | Nombre del artículo |
| cantidad_cajas | DECIMAL(10,2) | Cantidad de cajas |
| unidades_por_caja | DECIMAL(10,2) | Unidades por caja |
| unidades_totales | INTEGER | Total de unidades |
| moneda_origen | VARCHAR(10) | Moneda de origen |
| valor_unitario_origen | DECIMAL(15,4) | Valor unitario |
| valor_proveedor_origen | DECIMAL(15,4) | Valor del proveedor original |
| importe_total_origen | DECIMAL(15,2) | Importe total |
| derechos_porcentaje | DECIMAL(5,4) | % de derechos (ej: 0.18) |
| impuesto_interno_porcentaje | DECIMAL(5,4) | % impuesto interno |
| fob_unitario_usd | DECIMAL(15,4) | FOB unitario USD |
| fob_total_usd | DECIMAL(15,2) | FOB total USD |
| fob_unitario_ars | DECIMAL(15,4) | FOB unitario ARS |
| fob_total_ars | DECIMAL(15,2) | FOB total ARS |
| participacion_fob | DECIMAL(10,6) | % participación FOB |
| anmat_ars | DECIMAL(15,2) | ANMAT |
| gastos_base_aduana_ars | DECIMAL(15,2) | Gastos para base aduana |
| base_aduana_ars | DECIMAL(15,2) | Base imponible aduana |
| derechos_ars | DECIMAL(15,2) | Derechos de importación |
| estadistica_ars | DECIMAL(15,2) | Tasa de estadística |
| gastos_prorrateo_ars | DECIMAL(15,2) | Gastos prorrateados |
| costo_total_neto_ars | DECIMAL(15,2) | Costo total neto |
| costo_unitario_neto_ars | DECIMAL(15,4) | Costo unitario neto |
| iva_unitario_ars | DECIMAL(15,4) | IVA unitario |
| iva_total_ars | DECIMAL(15,2) | IVA total |
| impuesto_interno_unitario_ars | DECIMAL(15,4) | Imp. interno unitario |
| impuesto_interno_total_ars | DECIMAL(15,2) | Imp. interno total |
| costo_unitario_ars | DECIMAL(15,4) | Costo unitario final |
| costo_total_ars | DECIMAL(15,2) | Costo total final |
| factor_importacion | DECIMAL(10,4) | Factor de importación |
| created_at | TIMESTAMP | Fecha de creación |
| updated_at | TIMESTAMP | Fecha de actualización |

## 4.6 Tabla: gastos_aduana

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | UUID | Clave primaria |
| costeo_id | UUID | FK a costeos |
| despachante | DECIMAL(15,2) | Honorarios despachante |
| gestion_senasa | DECIMAL(15,2) | Gestión SENASA |
| gestion_anmat | DECIMAL(15,2) | Gestión ANMAT |
| transporte_internacional | DECIMAL(15,2) | Transporte internacional |
| gastos_origen | DECIMAL(15,2) | Gastos de origen |
| terminal | DECIMAL(15,2) | Terminal |
| maritima_agencia | DECIMAL(15,2) | Marítima/Agencia |
| bancarios | DECIMAL(15,2) | Gastos bancarios |
| gestor | DECIMAL(15,2) | Gestor |
| transporte_nacional | DECIMAL(15,2) | Transporte nacional |
| custodia | DECIMAL(15,2) | Custodia |
| sim | DECIMAL(15,2) | SIM |
| total_gastos_ars | DECIMAL(15,2) | Total gastos |
| created_at | TIMESTAMP | Fecha de creación |
| updated_at | TIMESTAMP | Fecha de actualización |

## 4.7 Tabla: gastos_varios

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | UUID | Clave primaria |
| costeo_id | UUID | FK a costeos |
| descripcion | VARCHAR(255) | Descripción del gasto |
| proveedor_gasto | VARCHAR(255) | Proveedor del gasto |
| nro_comprobante | VARCHAR(100) | Número de comprobante |
| moneda | VARCHAR(10) | Moneda |
| monto | DECIMAL(15,2) | Monto |
| monto_ars | DECIMAL(15,2) | Monto en ARS |
| recargo | DECIMAL(5,2) | % de recargo |
| observaciones | TEXT | Observaciones |
| created_at | TIMESTAMP | Fecha de creación |
| updated_at | TIMESTAMP | Fecha de actualización |

---

# 5. ESTRUCTURA DEL PROYECTO

```
C:\Users\Admin\Desktop\sistema-costeo-backend\
│
├── config/
│   └── database.js          # Configuración de PostgreSQL/Sequelize
│
├── controllers/
│   ├── authController.js    # Lógica de autenticación
│   └── costeoController.js  # Lógica de costeos
│
├── middleware/
│   └── auth.js              # Middleware de verificación JWT
│
├── models/
│   ├── Usuario.js           # Modelo de usuarios
│   ├── Empresa.js           # Modelo de empresas
│   ├── Costeo.js            # Modelo de costeos
│   ├── ArticuloCosteo.js    # Modelo de artículos
│   ├── GastosAduana.js      # Modelo de gastos aduana
│   ├── GastosVarios.js      # Modelo de gastos varios
│   └── index.js             # Relaciones entre modelos
│
├── routes/
│   ├── authRoutes.js        # Rutas de autenticación
│   └── costeoRoutes.js      # Rutas de costeos
│
├── public/
│   └── index.html           # Frontend completo
│
├── .env                     # Variables de entorno
├── server.js                # Servidor principal
├── package.json             # Dependencias del proyecto
└── node_modules/            # Dependencias instaladas
```

---

# 6. API - ENDPOINTS

## 6.1 Autenticación

### POST /api/auth/register
Registra un nuevo usuario.

**Request:**
```json
{
    "email": "usuario@goodies.com.ar",
    "password": "contraseña123",
    "nombre": "NOMBRE USUARIO",
    "rol": "comex"
}
```

**Response:**
```json
{
    "mensaje": "Usuario registrado exitosamente",
    "token": "eyJ...",
    "usuario": {
        "id": "uuid",
        "email": "usuario@goodies.com.ar",
        "nombre": "NOMBRE USUARIO",
        "rol": "comex"
    }
}
```

### POST /api/auth/login
Inicia sesión.

**Request:**
```json
{
    "email": "lpardina@goodies.com.ar",
    "password": "admin123"
}
```

**Response:**
```json
{
    "mensaje": "Login exitoso",
    "token": "eyJ...",
    "usuario": {
        "id": "uuid",
        "email": "lpardina@goodies.com.ar",
        "nombre": "LUZ PARDINA",
        "rol": "admin"
    }
}
```

### GET /api/auth/me
Obtiene información del usuario actual (requiere token).

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
    "usuario": {
        "id": "uuid",
        "email": "lpardina@goodies.com.ar",
        "nombre": "LUZ PARDINA",
        "rol": "admin",
        "activo": true
    }
}
```

## 6.2 Costeos

### GET /api/costeos/listar
Lista todos los costeos del usuario.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
[
    {
        "id": "uuid",
        "nombre_costeo": "BACKUS 1-25",
        "proveedor": "BACKUS",
        "moneda_principal": "USD",
        "unidades_totales": 240,
        "fecha_factura": "2025-01-15",
        "fecha_despacho": "2025-01-20",
        "estado": "calculado",
        "created_at": "2025-01-10T..."
    }
]
```

### GET /api/costeos/:id
Obtiene un costeo específico con todos sus detalles.

**Response:**
```json
{
    "id": "uuid",
    "nombre_costeo": "BACKUS 1-25",
    "proveedor": "BACKUS",
    "articulos": [...],
    "gastos_aduana": {...},
    "gastos_varios": [...]
}
```

### POST /api/costeos/manual
Crea un costeo manualmente.

**Request:**
```json
{
    "nombre_costeo": "TEST 1-25",
    "proveedor": "PROVEEDOR",
    "moneda_principal": "USD",
    "tc_usd": 1450,
    "articulos": [
        {
            "codigo_goodies": "COD1",
            "nombre": "Producto",
            "cantidad_cajas": 10,
            "unidades_por_caja": 24,
            "valor_unitario_origen": 5.50,
            "derechos_porcentaje": 0.18
        }
    ],
    "gastos": [...]
}
```

### POST /api/costeos/precargar
Lee un Excel y devuelve los datos sin guardar (para pre-visualización).

**Request:** Form-data con archivo Excel

**Response:**
```json
{
    "nombre_costeo": "BACKUS 1-25",
    "proveedor": "BACKUS",
    "articulos": [...],
    "gastos": [...]
}
```

### POST /api/costeos/importar
Importa un Excel y guarda el costeo directamente.

### PUT /api/costeos/:id/actualizar
Actualiza un costeo existente.

### POST /api/costeos/:id/calcular
Ejecuta los cálculos de un costeo.

**Response:**
```json
{
    "mensaje": "Costeo calculado exitosamente",
    "resumen": {
        "costo_total_final_ars": 125000.00,
        "costo_unitario_promedio": 520.83
    }
}
```

### GET /api/costeos/:id/exportar
Exporta un costeo a Excel.

### DELETE /api/costeos/:id
Elimina un costeo.

### GET /api/costeos/ultimos-costos
Obtiene el último costo de cada artículo.

**Response:**
```json
[
    {
        "codigo_goodies": "COD1",
        "proveedor": "BACKUS",
        "nombre": "Producto",
        "moneda_fob": "USD",
        "valor_fob": 5.50,
        "costo_neto": 8500.00,
        "costo_con_impuestos": 10285.00,
        "costo_anterior": 9800.00,
        "diferencia_pct": 4.95,
        "fecha_despacho": "2025-01-20",
        "nombre_costeo": "BACKUS 1-25",
        "tc_usd": 1450
    }
]
```

---

# 7. FUNCIONALIDADES DEL SISTEMA

## 7.1 Autenticación

- Login con email y contraseña
- Token JWT válido por 24 horas
- Roles: admin, comex, comercial, contable, visualizador
- Logout (elimina token del navegador)

## 7.2 Listado de Costeos

### Columnas mostradas:
- Checkbox de selección
- Nombre
- Proveedor
- Moneda
- Unidades
- Fecha Factura
- Fecha Despacho
- Tipo (Definitivo/Presupuesto)
- Acciones (Calc, Edit, Dup, Leg, Ver, Excel, X)

### Filtros disponibles:
- Por Proveedor (dropdown)
- Por Tipo (Definitivo/Presupuesto/Todos)
- Solo última versión (con criterio: fecha carga, fecha factura, fecha despacho)

### Criterio Definitivo vs Presupuesto:
- **Definitivo**: Tiene fecha_factura Y fecha_despacho
- **Presupuesto**: Falta alguna de las dos fechas

### Acciones en cada costeo:
| Botón | Función |
|-------|---------|
| Calc | Ejecuta los cálculos del costeo |
| Edit | Abre el costeo para edición |
| Dup | Duplica el costeo como base para uno nuevo |
| Leg | Exporta el legajo completo a Excel |
| Ver | Muestra resumen del costeo |
| Excel | Exporta el costeo calculado |
| X | Elimina el costeo |

### Acciones masivas:
- Seleccionar múltiples costeos con checkboxes
- Exportar seleccionados
- Recalcular con nuevo TC

## 7.3 Carga Manual de Legajos

### Tab 1: Datos Generales
| Campo | Tipo | Obligatorio |
|-------|------|-------------|
| Nombre del Costeo | Texto | Sí |
| Proveedor de Origen | Texto | Sí |
| Tiene Empresa Intermediaria | Checkbox | No |
| Nombre Empresa Intermediaria | Texto | Condicional |
| Nro Factura Intermediaria | Texto | Condicional |
| Fecha Factura Intermediaria | Fecha | Condicional |
| Fecha Vencimiento Intermediaria | Fecha | Condicional |
| Factura Nro | Texto | No |
| Moneda Principal | Select (USD/EUR/GBP) | Sí |
| Monto Factura | Número | No |
| Fecha Factura | Fecha | No |
| Fecha Vencimiento | Fecha | No |
| Fecha Despacho | Fecha | No |
| TC USD | Número | No |
| TC EUR | Número | No |
| TC GBP | Número | No |

### Tab 2: Base Aduana
| Campo | Tipo |
|-------|------|
| Puesta FOB - Moneda | Select |
| Puesta FOB - Monto | Número |
| Flete Aduana - Moneda | Select |
| Flete Aduana - Monto | Número |
| Seguro Aduana - Moneda | Select |
| Seguro Aduana - Monto | Número |

### Tab 3: Artículos
Tabla dinámica con columnas:
- # (número de fila)
- Código Goodies
- Código Proveedor
- Nombre
- Cajas
- Und/Caja
- Valor Origen
- Valor Intermediaria (editable solo si tiene intermediaria)
- % Derecho
- % Imp. Interno
- Botón eliminar (X)

**Funcionalidades:**
- Botón "+ Agregar Artículo"
- Botón "Descargar Template"
- Botón "Importar desde Excel"
- Cálculo automático de Valor Intermediaria con % margen

**Lógica de Valor Intermediaria:**
- Sin intermediaria: Valor Interm = Valor Origen (automático, readonly)
- Con intermediaria: Editable o calculado con fórmula

**Fórmula de margen (marginal):**
```
Valor Intermediaria = Valor Origen / (1 - %Margen/100)
Ejemplo: Origen $100, Margen 20% → 100 / 0.80 = $125
```

### Tab 4: Gastos
Tabla dinámica con columnas:
- # (número de fila)
- Descripción
- Proveedor
- Nro Comprobante (vacío = "ESTIMADO")
- Moneda (USD/EUR/GBP/ARS)
- Monto
- % Recargo
- Observaciones
- Botón eliminar (X)

**Funcionalidades:**
- Botón "+ Agregar Gasto"
- Botón "Descargar Template"
- Botón "Importar desde Excel"

## 7.4 Importación de Excel

### Proceso:
1. Click en "Importar Excel"
2. Arrastrar o seleccionar archivo
3. Click en "Importar"
4. Se abre ventana de Carga Manual con datos pre-cargados
5. Usuario revisa y modifica si es necesario
6. Click en "Guardar Costeo"

### Hojas requeridas en el Excel:
- DATOS_GENERALES
- ARTICULOS
- BASE_ADUANA_GASTOS

### Formatos soportados para gastos:
**Formato NUEVO:**
- Fila 12+
- A=Descripción, B=Proveedor, C=Nro Comprobante, D=Moneda, E=Monto, F=Recargo, G=Observaciones

**Formato VIEJO:**
- Fila 12+
- A=Proveedor/Gasto, B=Factura/Tipo, C=Moneda, D=Importe

### Campos de Intermediaria en Excel (DATOS_GENERALES):
- Empresa Intermediaria
- Nro Factura Intermediaria
- Fecha Factura Intermediaria
- Fecha Vencimiento intermediaria

## 7.5 Edición de Costeos

- Click en botón "Edit" del costeo
- Se abre la ventana de Carga Manual con todos los datos cargados
- Modificar lo necesario
- Click en "Guardar Costeo"
- El sistema actualiza (no crea duplicado)

## 7.6 Duplicación de Costeos

- Click en botón "Dup" del costeo
- Se abre la ventana de Carga Manual con datos copiados
- Nombre automático: "NOMBRE ORIGINAL - COPIA"
- Campos vacíos: fechas, valores de artículos, montos de gastos
- Completar los datos nuevos
- Click en "Guardar Costeo"
- Se crea un nuevo costeo

## 7.7 Exportación de Legajo

- Click en botón "Leg" del costeo
- Se descarga archivo Excel con:
  - DATOS GENERALES (todos los campos)
  - ARTICULOS (todos los campos)
  - GASTOS (todos los campos)
- Formato: texto tabulado (.xls)
- Nombre: Legajo_NOMBRE_COSTEO.xls

## 7.8 Último Costo por Artículo

### Ubicación:
Sección debajo del Listado de Costeos

### Filtros:
- Buscar por código o nombre
- Filtrar por proveedor

### Columnas:
- Código
- Proveedor
- Nombre
- Mon. FOB (moneda)
- Valor FOB
- Costo Neto
- Costo c/Imp (con impuestos)
- Costo Anterior
- Dif % (diferencia porcentual)
- Fecha Despacho
- Costeo (nombre del costeo origen)
- TC (tipos de cambio)

### Colores en Dif %:
- **Rojo**: Aumento de precio (+)
- **Verde**: Disminución de precio (-)
- **Blanco**: Sin cambio o sin dato anterior

### Exportar:
- Botón "Exportar Excel"
- Descarga todos los artículos filtrados
- Incluye todas las columnas

---

# 8. GUÍA DE USO

## 8.1 Iniciar el Sistema

1. Abrir CMD
2. Navegar: `cd Desktop\sistema-costeo-backend`
3. Ejecutar: `node server.js`
4. Abrir navegador: `http://localhost:3000`
5. Login con credenciales

## 8.2 Cargar un Nuevo Costeo

### Opción A: Carga Manual
1. Click en "+ Carga Manual"
2. Completar Tab 1: Datos Generales
3. Completar Tab 2: Base Aduana
4. Completar Tab 3: Artículos (agregar uno por uno o importar)
5. Completar Tab 4: Gastos (agregar uno por uno o importar)
6. Click en "Guardar Costeo"
7. Click en "Calc" para ejecutar cálculos

### Opción B: Importar Excel
1. Click en "Importar Excel"
2. Arrastrar archivo Excel
3. Click en "Importar"
4. Revisar datos en la ventana de Carga Manual
5. Modificar si es necesario
6. Click en "Guardar Costeo"
7. Click en "Calc" para ejecutar cálculos

## 8.3 Editar un Costeo Existente

1. Buscar el costeo en el listado
2. Click en "Edit"
3. Modificar los datos necesarios
4. Click en "Guardar Costeo"
5. Click en "Calc" para recalcular

## 8.4 Duplicar un Costeo

1. Buscar el costeo base en el listado
2. Click en "Dup"
3. Completar los nuevos datos (fechas, valores, etc.)
4. Cambiar el nombre si es necesario
5. Click en "Guardar Costeo"
6. Click en "Calc" para calcular

## 8.5 Consultar Últimos Costos

1. Ir a la sección "Último Costo por Artículo"
2. Usar el buscador o filtros
3. Ver costos actuales, anteriores y diferencias
4. Click en "Exportar Excel" para descargar

## 8.6 Exportar Información

### Exportar Costeo Calculado:
- Click en "Excel" del costeo

### Exportar Legajo Completo:
- Click en "Leg" del costeo

### Exportar Últimos Costos:
- Click en "Exportar Excel" en la sección de últimos costos

---

# 9. FÓRMULAS Y CÁLCULOS

## 9.1 Unidades Totales
```
Unidades Totales = Cantidad Cajas × Unidades por Caja
```

## 9.2 FOB
```
FOB Unitario = Valor Unitario Intermediaria (o Valor Origen si no hay intermediaria)
FOB Total = FOB Unitario × Unidades Totales
```

## 9.3 Participación FOB
```
Participación FOB = FOB Total Artículo / FOB Total Costeo
```

## 9.4 Base Aduana
```
Gastos Base Aduana = (Flete Aduana + Seguro Aduana) × Participación FOB
Base Aduana = FOB Total ARS + Gastos Base Aduana
```

## 9.5 Derechos de Importación
```
Derechos = Base Aduana × % Derechos
```

## 9.6 Estadística
```
Estadística = Base Aduana × 3% (solo si tiene derechos > 0)
```

## 9.7 ANMAT
```
ANMAT = FOB Total × 0.5%
```

## 9.8 Gastos Prorrateados
```
Gastos Prorrateo = Total Gastos × Participación FOB
```

## 9.9 Costo Neto
```
Costo Total Neto = FOB ARS + Derechos + Estadística + ANMAT + Gastos Prorrateo
Costo Unitario Neto = Costo Total Neto / Unidades Totales
```

## 9.10 IVA
```
IVA = Costo Total Neto × 21%
```

## 9.11 Impuesto Interno
```
Impuesto Interno = Costo Total Neto × % Impuesto Interno del artículo
```

## 9.12 Costo Final
```
Costo Total Final = Costo Total Neto + IVA + Impuesto Interno
Costo Unitario Final = Costo Total Final / Unidades Totales
```

## 9.13 Factor de Importación
```
Factor Importación = Costo Unitario Final / FOB Unitario
```

## 9.14 Valor Intermediaria (con margen)
```
Valor Intermediaria = Valor Origen / (1 - %Margen/100)
```

## 9.15 Diferencia Porcentual
```
Diferencia % = ((Costo Actual - Costo Anterior) / Costo Anterior) × 100
```

---

# 10. TROUBLESHOOTING

## 10.1 El servidor no inicia

**Problema:** Error al ejecutar `node server.js`

**Soluciones:**
1. Verificar que PostgreSQL está corriendo:
   - Menú Windows → Servicios
   - Buscar "postgresql-x64-16"
   - Debe estar "En ejecución"

2. Verificar credenciales en .env:
   ```
   DB_PASSWORD=postgres123
   DB_NAME=sistema_costeo
   ```

3. Verificar que el puerto 3000 está libre

## 10.2 Error de conexión a base de datos

**Problema:** "Connection refused" o similar

**Soluciones:**
1. Reiniciar PostgreSQL desde Servicios
2. Verificar que pgAdmin puede conectarse
3. Verificar puerto 5432

## 10.3 Token inválido

**Problema:** Error "Token inválido" al hacer peticiones

**Soluciones:**
1. Hacer logout y login nuevamente
2. El token expira después de 24 horas
3. Limpiar localStorage del navegador

## 10.4 No aparecen los costeos

**Problema:** La lista de costeos está vacía

**Soluciones:**
1. Verificar que hay costeos cargados
2. Limpiar filtros (botón "Limpiar")
3. Refrescar con Ctrl+Shift+R

## 10.5 El Excel no se importa

**Problema:** Error al importar archivo Excel

**Soluciones:**
1. Verificar que el archivo es .xlsx o .xls
2. Verificar que tiene las hojas requeridas:
   - DATOS_GENERALES
   - ARTICULOS
   - BASE_ADUANA_GASTOS
3. Verificar que los campos obligatorios están completos

## 10.6 Los cálculos no se guardan

**Problema:** Después de calcular, los valores no aparecen

**Soluciones:**
1. Verificar que el cálculo terminó sin errores
2. Refrescar la página
3. Verificar en "Ver" que los valores están

## 10.7 Caracteres raros en importación

**Problema:** Al importar template, aparecen símbolos extraños

**Solución:**
- No usar los templates generados por el sistema
- Crear el archivo Excel manualmente o usar el legajo original

---

# 11. HISTORIAL DE SESIONES

## Sesión 1 - 11/12/2025
- ✅ Instalación de PostgreSQL 16
- ✅ Configuración de pgAdmin
- ✅ Creación de base de datos `sistema_costeo`
- ✅ Creación de 6 tablas iniciales
- ✅ Usuario administrador creado

## Sesión 2 - 12/12/2025
- ✅ Instalación de Node.js
- ✅ Creación del proyecto backend
- ✅ Configuración de Express
- ✅ Conexión a PostgreSQL con Sequelize
- ✅ Servidor funcionando en puerto 3000

## Sesión 3 - 12/12/2025
- ✅ Modelos de Sequelize (Usuario, Empresa)
- ✅ Sistema de autenticación JWT
- ✅ Endpoints de registro, login, me
- ✅ Middleware de autenticación
- ✅ Interfaz de prueba (test-auth.html)

## Sesión 4 - 12/12/2025
- ✅ Modelos de Costeo, ArticuloCosteo, GastosAduana, GastosVarios
- ✅ Controlador de importación de Excel
- ✅ Lectura dinámica de artículos (1-50)
- ✅ Lectura dinámica de gastos (0-50)
- ✅ Conversión de monedas
- ⚠️ Problema con estructura de tablas (resuelto en sesión posterior)

## Sesión 5 - (No documentada separadamente)
- ✅ Resolución de problemas de tablas
- ✅ Pruebas de importación

## Sesión 6 - 28/12/2025
- ✅ Interfaz web completa (index.html)
- ✅ Sistema de filtros avanzados
- ✅ Checkbox de selección múltiple
- ✅ Acciones masivas
- ✅ Corrección de criterio Definitivo/Presupuesto
- ✅ Corrección de importación de fechas Excel

## Sesión 7 - 28/12/2025
- ✅ Carga manual de legajos (4 tabs)
- ✅ Campos de empresa intermediaria
- ✅ Cálculo de márgenes
- ✅ Lógica de Valor Origen / Valor Intermediaria

## Sesión 8 - 29/12/2025
- ✅ Campos Factura y Fecha Intermediaria
- ✅ Importar Excel → pre-cargar en Carga Manual
- ✅ Botón Duplicar costeo (Dup)
- ✅ Botón Exportar legajo (Leg)
- ✅ Campos FOB, Flete, Seguro, Valor Origen en BD
- ✅ Columna Fecha Despacho en listado
- ✅ Edición de costeos existentes
- ✅ Soporte para formato de gastos viejo y nuevo
- ✅ Campos de intermediaria desde Excel
- ✅ Consulta de Último Costo por Artículo
- ✅ Costo Anterior y Diferencia %
- ✅ Exportación de últimos costos

---

# 12. PENDIENTES Y MEJORAS FUTURAS

## 12.1 Funcionalidades Pendientes

| # | Funcionalidad | Prioridad | Estado |
|---|---------------|-----------|--------|
| 1 | Revaluación de costos con nuevo TC | Media | Pendiente |
| 2 | Análisis de márgenes | Media | Pendiente |
| 3 | Histórico consolidado por proveedor/artículo | Baja | Pendiente |
| 4 | Mejorar templates de importación | Baja | Pendiente |

## 12.2 Mejoras Sugeridas

1. **Dashboard con gráficos**
   - Evolución de costos por artículo
   - Comparativa entre proveedores
   - Volumen de importaciones

2. **Alertas**
   - Variación de precios > X%
   - Costeos sin calcular
   - Vencimientos próximos

3. **Reportes**
   - Reporte mensual de importaciones
   - Análisis de rentabilidad
   - Comparativa de tipos de cambio

4. **Multi-usuario avanzado**
   - Permisos por rol
   - Auditoría de cambios
   - Aprobaciones de costeos

5. **Integración**
   - Conexión con sistema contable
   - Importación de TC automática
   - Notificaciones por email

---

# ANEXOS

## A. Comandos Útiles

### Iniciar servidor:
```bash
cd Desktop\sistema-costeo-backend
node server.js
```

### Ver logs de error:
```bash
node server.js > log.txt 2>&1
type log.txt
```

### Reiniciar servidor:
```
Ctrl+C → S → Enter
node server.js
```

### Verificar PostgreSQL:
```
Servicios → postgresql-x64-16 → Estado
```

## B. URLs del Sistema

| URL | Descripción |
|-----|-------------|
| http://localhost:3000 | Aplicación principal |
| http://localhost:3000/health | Health check |
| http://localhost:3000/api/auth/login | Login API |
| http://localhost:3000/api/costeos/listar | Listar costeos API |

## C. Credenciales

### PostgreSQL:
```
Host: localhost
Puerto: 5432
Usuario: postgres
Password: postgres123
Base de datos: sistema_costeo
```

### Usuario Admin:
```
Email: lpardina@goodies.com.ar
Password: admin123
```

### Usuario Comex:
```
Email: comercioexterior@goodies.com.ar
Password: COMEX123
```

---

**Documento generado el:** 29 de Diciembre de 2025
**Versión del documento:** 1.0
**Sistema de Costeo GOODIES** - Todos los derechos reservados
