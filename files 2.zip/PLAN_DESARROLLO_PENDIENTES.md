# ANÁLISIS Y PLAN DE DESARROLLO
# FUNCIONALIDADES PENDIENTES - SISTEMA DE COSTEO GOODIES

## Fecha: Diciembre 2025
## Estado: ANÁLISIS PREVIO A DESARROLLO

---

# ÍNDICE DE PENDIENTES

| # | Funcionalidad | Prioridad | Complejidad | Tiempo Est. |
|---|---------------|-----------|-------------|-------------|
| 1 | Revaluación de Costos con nuevo TC | ALTA | Alta | 2-3 horas |
| 2 | Consolidado de Costos | ALTA | Media | 1-2 horas |
| 3 | Análisis de Márgenes | ALTA | Alta | 2-3 horas |
| 4 | Variación de Precios FOB | MEDIA | Baja | 30-45 min |
| 5 | Exportar en Listado de Costeos | MEDIA | Baja | 30 min |
| 6 | OCR de Comprobantes | BAJA | Muy Alta | Análisis |
| 7 | Cálculo de Impuestos para Liberación | ALTA | Media | 1-2 horas |

---

# 1. REVALUACIÓN DE COSTOS CON NUEVO TC

## 1.1 Descripción Funcional

Permitir recalcular costeos existentes utilizando nuevos tipos de cambio, guardando el resultado como un nuevo registro de "Revaluación".

## 1.2 Requerimientos

### Nivel Individual (1 costeo):
- Botón "Revaluar" en cada costeo del listado
- Abre ventana modal para ingresar nuevos TC
- Guarda como nuevo costeo tipo "Revaluación"

### Nivel Global (múltiples costeos):
- Seleccionar varios costeos con checkboxes
- Botón "Revaluar Seleccionados" en barra de acciones
- Misma ventana modal con TC
- Genera múltiples revaluaciones

### Datos a solicitar en la ventana:
```
┌─────────────────────────────────────────────────┐
│           REVALUACIÓN DE COSTOS                 │
├─────────────────────────────────────────────────┤
│                                                 │
│  Fecha de Revaluación: [DD/MM/AAAA]            │
│                                                 │
│  Nuevos Tipos de Cambio:                        │
│  ┌─────────────────────────────────────────┐   │
│  │ TC USD: [__________]                     │   │
│  │ TC EUR: [__________]                     │   │
│  │ TC GBP: [__________]                     │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  Motivo de Revaluación:                         │
│  ○ Revaluación Contable                         │
│  ○ Análisis de Margen                           │
│  ○ Actualización Costos de Reposición           │
│  ○ Otro: [__________________]                   │
│                                                 │
│  [Cancelar]              [Revaluar]             │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Nombre del costeo generado:
```
"REVALUACION AL DD/MM/AAAA - [MOTIVO] - [NOMBRE_COSTEO_ORIGINAL]"

Ejemplos:
- "REVALUACION AL 29/12/2025 - CONTABLE - KB 1-25"
- "REVALUACION AL 29/12/2025 - MARGEN - BACKUS 4-25"
```

### Lógica de cálculo:
1. Tomar el ÚLTIMO costeo DEFINITIVO de cada artículo
2. Aplicar los nuevos TC a los valores en moneda extranjera
3. Recalcular: FOB ARS, CIF ARS, Derechos, Estadística, IVA, Imp. Interno
4. Guardar como nuevo costeo con estado "revaluacion"

## 1.3 Modelo de Datos

### Agregar campo en tabla `costeos`:
```sql
ALTER TABLE costeos ADD COLUMN tipo_costeo VARCHAR(50) DEFAULT 'original';
-- Valores: 'original', 'revaluacion'

ALTER TABLE costeos ADD COLUMN motivo_revaluacion VARCHAR(255);
-- Ej: "Revaluación Contable", "Análisis de Margen"

ALTER TABLE costeos ADD COLUMN costeo_origen_id UUID REFERENCES costeos(id);
-- Referencia al costeo original que se revaluó
```

## 1.4 Nuevo Endpoint API

```javascript
// POST /api/costeos/revaluar
// Body: {
//   costeo_ids: ['uuid1', 'uuid2', ...],  // IDs de costeos a revaluar
//   fecha_revaluacion: '2025-12-29',
//   tc_usd: 1500,
//   tc_eur: 1650,
//   tc_gbp: 1900,
//   motivo: 'Revaluación Contable'
// }
```

## 1.5 Código Preparado

### Backend - routes/costeoRoutes.js
```javascript
router.post('/revaluar', auth, async (req, res) => {
    try {
        const { costeo_ids, fecha_revaluacion, tc_usd, tc_eur, tc_gbp, motivo } = req.body;
        
        if (!costeo_ids || costeo_ids.length === 0) {
            return res.status(400).json({ error: 'Debe seleccionar al menos un costeo' });
        }
        
        if (!tc_usd) {
            return res.status(400).json({ error: 'Debe ingresar el TC USD' });
        }
        
        const revaluaciones = [];
        const fechaFormateada = new Date(fecha_revaluacion).toLocaleDateString('es-AR');
        
        for (const costeoId of costeo_ids) {
            // Obtener costeo original con artículos
            const costeoOriginal = await Costeo.findByPk(costeoId, {
                include: [
                    { model: ArticuloCosteo, as: 'articulos' },
                    { model: GastosAduana, as: 'gastos_aduana' },
                    { model: GastosVarios, as: 'gastos_varios' }
                ]
            });
            
            if (!costeoOriginal) continue;
            
            // Crear nombre de revaluación
            const nombreRevaluacion = `REVALUACION AL ${fechaFormateada} - ${motivo.toUpperCase()} - ${costeoOriginal.nombre_costeo}`;
            
            // Crear nuevo costeo de revaluación
            const revaluacion = await Costeo.create({
                usuario_id: req.usuario.id,
                empresa_id: costeoOriginal.empresa_id,
                nombre_costeo: nombreRevaluacion,
                proveedor: costeoOriginal.proveedor,
                moneda_principal: costeoOriginal.moneda_principal,
                tc_usd: tc_usd,
                tc_eur: tc_eur || costeoOriginal.tc_eur,
                tc_gbp: tc_gbp || costeoOriginal.tc_gbp,
                fob_moneda: costeoOriginal.fob_moneda,
                fob_monto: costeoOriginal.fob_monto,
                flete_moneda: costeoOriginal.flete_moneda,
                flete_monto: costeoOriginal.flete_monto,
                seguro_moneda: costeoOriginal.seguro_moneda,
                seguro_monto: costeoOriginal.seguro_monto,
                tipo_costeo: 'revaluacion',
                motivo_revaluacion: motivo,
                costeo_origen_id: costeoOriginal.id,
                estado: 'pendiente'
            });
            
            // Copiar artículos
            for (const art of costeoOriginal.articulos) {
                await ArticuloCosteo.create({
                    costeo_id: revaluacion.id,
                    codigo_goodies: art.codigo_goodies,
                    codigo_proveedor: art.codigo_proveedor,
                    nombre: art.nombre,
                    cantidad_cajas: art.cantidad_cajas,
                    unidades_por_caja: art.unidades_por_caja,
                    unidades_totales: art.unidades_totales,
                    moneda_origen: art.moneda_origen,
                    valor_unitario_origen: art.valor_unitario_origen,
                    valor_proveedor_origen: art.valor_proveedor_origen,
                    derechos_porcentaje: art.derechos_porcentaje,
                    impuesto_interno_porcentaje: art.impuesto_interno_porcentaje
                });
            }
            
            // Copiar gastos varios
            for (const gasto of costeoOriginal.gastos_varios) {
                await GastosVarios.create({
                    costeo_id: revaluacion.id,
                    descripcion: gasto.descripcion,
                    proveedor_gasto: gasto.proveedor_gasto,
                    nro_comprobante: gasto.nro_comprobante,
                    moneda: gasto.moneda,
                    monto: gasto.monto,
                    recargo: gasto.recargo,
                    observaciones: gasto.observaciones
                });
            }
            
            revaluaciones.push(revaluacion);
        }
        
        // Calcular cada revaluación
        for (const rev of revaluaciones) {
            // Llamar a la función de cálculo existente
            await calcularCosteo(rev.id);
        }
        
        res.json({
            mensaje: `Se crearon ${revaluaciones.length} revaluaciones exitosamente`,
            revaluaciones: revaluaciones.map(r => ({
                id: r.id,
                nombre: r.nombre_costeo
            }))
        });
        
    } catch (error) {
        console.error('Error al revaluar:', error);
        res.status(500).json({ error: 'Error al crear revaluaciones' });
    }
});
```

### Frontend - Modal de Revaluación (HTML)
```html
<div class="modal" id="revaluarModal">
    <div class="modal-content" style="max-width: 500px;">
        <div class="modal-header">
            <h3>Revaluación de Costos</h3>
            <button class="modal-close" onclick="cerrarModal('revaluarModal')">×</button>
        </div>
        <div class="modal-body">
            <p id="revaluarInfo">Se revaluarán X costeos seleccionados</p>
            
            <div class="form-group">
                <label>Fecha de Revaluación</label>
                <input type="date" id="rev_fecha" value="">
            </div>
            
            <h4>Nuevos Tipos de Cambio</h4>
            <div class="form-row">
                <div class="form-group">
                    <label>TC USD *</label>
                    <input type="number" id="rev_tcUsd" step="0.0001" required>
                </div>
                <div class="form-group">
                    <label>TC EUR</label>
                    <input type="number" id="rev_tcEur" step="0.0001">
                </div>
                <div class="form-group">
                    <label>TC GBP</label>
                    <input type="number" id="rev_tcGbp" step="0.0001">
                </div>
            </div>
            
            <div class="form-group">
                <label>Motivo de Revaluación *</label>
                <select id="rev_motivo">
                    <option value="">Seleccionar...</option>
                    <option value="Revaluación Contable">Revaluación Contable</option>
                    <option value="Análisis de Margen">Análisis de Margen</option>
                    <option value="Actualización Costos Reposición">Actualización Costos de Reposición</option>
                    <option value="Otro">Otro</option>
                </select>
            </div>
            
            <div class="form-group" id="rev_otroMotivoGroup" style="display:none;">
                <label>Especificar Motivo</label>
                <input type="text" id="rev_otroMotivo" placeholder="Ingrese el motivo">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="cerrarModal('revaluarModal')">Cancelar</button>
            <button class="btn btn-primary" onclick="ejecutarRevaluacion()">Revaluar</button>
        </div>
    </div>
</div>
```

### Frontend - JavaScript
```javascript
let costeosARevaluar = [];

function abrirRevaluar(costeoId = null) {
    if (costeoId) {
        // Revaluación individual
        costeosARevaluar = [costeoId];
        document.getElementById('revaluarInfo').textContent = 'Se revaluará 1 costeo';
    } else {
        // Revaluación múltiple (desde selección)
        costeosARevaluar = Array.from(seleccionados);
        if (costeosARevaluar.length === 0) {
            alert('Debe seleccionar al menos un costeo');
            return;
        }
        document.getElementById('revaluarInfo').textContent = `Se revaluarán ${costeosARevaluar.length} costeos seleccionados`;
    }
    
    // Setear fecha de hoy
    document.getElementById('rev_fecha').value = new Date().toISOString().split('T')[0];
    document.getElementById('rev_tcUsd').value = '';
    document.getElementById('rev_tcEur').value = '';
    document.getElementById('rev_tcGbp').value = '';
    document.getElementById('rev_motivo').value = '';
    
    document.getElementById('revaluarModal').classList.add('show');
}

document.getElementById('rev_motivo').addEventListener('change', function() {
    document.getElementById('rev_otroMotivoGroup').style.display = 
        this.value === 'Otro' ? 'block' : 'none';
});

async function ejecutarRevaluacion() {
    const fecha = document.getElementById('rev_fecha').value;
    const tcUsd = parseFloat(document.getElementById('rev_tcUsd').value);
    const tcEur = parseFloat(document.getElementById('rev_tcEur').value) || null;
    const tcGbp = parseFloat(document.getElementById('rev_tcGbp').value) || null;
    let motivo = document.getElementById('rev_motivo').value;
    
    if (!fecha) {
        alert('Debe ingresar la fecha de revaluación');
        return;
    }
    if (!tcUsd) {
        alert('Debe ingresar el TC USD');
        return;
    }
    if (!motivo) {
        alert('Debe seleccionar un motivo');
        return;
    }
    
    if (motivo === 'Otro') {
        motivo = document.getElementById('rev_otroMotivo').value;
        if (!motivo) {
            alert('Debe especificar el motivo');
            return;
        }
    }
    
    try {
        const res = await fetch(API_URL + '/api/costeos/revaluar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify({
                costeo_ids: costeosARevaluar,
                fecha_revaluacion: fecha,
                tc_usd: tcUsd,
                tc_eur: tcEur,
                tc_gbp: tcGbp,
                motivo: motivo
            })
        });
        
        const data = await res.json();
        
        if (res.ok) {
            alert(data.mensaje);
            cerrarModal('revaluarModal');
            cargarCosteos();
            seleccionados.clear();
            actualizarBarraSeleccion();
        } else {
            alert('Error: ' + data.error);
        }
    } catch (err) {
        console.error(err);
        alert('Error al realizar la revaluación');
    }
}
```

---

# 2. CONSOLIDADO DE COSTOS

## 2.1 Descripción Funcional

Vista que muestra todos los costos de artículos (originales y revaluados) valuados a un TC específico, permitiendo comparar.

## 2.2 Diseño de Interfaz

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      CONSOLIDADO DE COSTOS                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Filtros:                                                                   │
│  Proveedor: [Todos ▼]  Artículo: [___________]  [Buscar]                   │
│                                                                             │
│  Valuar a TC:                                                               │
│  USD: [1500.00]  EUR: [1650.00]  GBP: [1900.00]  [Recalcular Vista]        │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌─────────┬──────────┬──────────┬──────────┬──────────┬──────────┬────────┐│
│ │ Código  │ Nombre   │ Costo    │ Costo    │ Costo    │ Dif vs   │ Dif vs ││
│ │         │          │ Original │ Revaluado│ A TC Nuevo│ Original │ Reval. ││
│ ├─────────┼──────────┼──────────┼──────────┼──────────┼──────────┼────────┤│
│ │ COD001  │ Producto │ $8,500   │ $9,200   │ $9,800   │ +15.3%   │ +6.5%  ││
│ │ COD002  │ Otro     │ $12,300  │ $13,100  │ $14,000  │ +13.8%   │ +6.9%  ││
│ └─────────┴──────────┴──────────┴──────────┴──────────┴──────────┴────────┘│
│                                                                             │
│  [Exportar Excel]                                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2.3 Columnas de la Tabla

| Columna | Descripción |
|---------|-------------|
| Código | Código Goodies del artículo |
| Nombre | Nombre del artículo |
| Proveedor | Proveedor de origen |
| Fecha Último Costeo | Fecha del último costeo definitivo |
| Costo Original | Último costo definitivo (TC original) |
| TC Original | TC usado en el costeo original |
| Costo Revaluado | Último costo de revaluación (si existe) |
| TC Revaluación | TC usado en la revaluación |
| Costo a TC Nuevo | Cálculo instantáneo con TC ingresado |
| Dif vs Original | % diferencia entre TC Nuevo y Original |
| Dif vs Revaluado | % diferencia entre TC Nuevo y Revaluado |

## 2.4 Lógica de Cálculo en Vista

```javascript
// Para cada artículo:
const costoOriginalUSD = articulo.fob_unitario_usd; // Valor en USD
const costoOriginalARS = articulo.costo_unitario_ars; // Calculado con TC original

// Recálculo instantáneo (sin guardar):
const costoNuevoARS = costoOriginalUSD * tcNuevoUSD; // Simplificado
// En realidad habría que recalcular todo: FOB + proporción gastos, etc.

const difVsOriginal = ((costoNuevoARS - costoOriginalARS) / costoOriginalARS) * 100;
```

---

# 3. ANÁLISIS DE MÁRGENES

## 3.1 Descripción Funcional

Comparar costos vs precios de venta de diferentes listas de precios para calcular rentabilidad.

## 3.2 Modelo de Datos

### Nueva tabla: `listas_precios`
```sql
CREATE TABLE listas_precios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID REFERENCES usuarios(id),
    nombre VARCHAR(255) NOT NULL,
    descripcion TEXT,
    moneda VARCHAR(10) DEFAULT 'ARS',
    fecha_vigencia DATE,
    activa BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

### Nueva tabla: `precios_articulos`
```sql
CREATE TABLE precios_articulos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lista_precio_id UUID REFERENCES listas_precios(id) ON DELETE CASCADE,
    codigo_goodies VARCHAR(50) NOT NULL,
    precio_unitario DECIMAL(15, 4) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

## 3.3 Diseño de Interfaz

### Gestión de Listas de Precios
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     LISTAS DE PRECIOS                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  [+ Nueva Lista]  [Importar Excel]                                          │
│                                                                             │
│ ┌──────────────────┬────────────┬────────────┬──────────┬─────────────────┐│
│ │ Nombre           │ Moneda     │ Vigencia   │ Artículos│ Acciones        ││
│ ├──────────────────┼────────────┼────────────┼──────────┼─────────────────┤│
│ │ Lista Mayorista  │ ARS        │ 01/12/2025 │ 150      │ [Ver][Edit][X]  ││
│ │ Lista Minorista  │ ARS        │ 01/12/2025 │ 150      │ [Ver][Edit][X]  ││
│ │ Lista Exportación│ USD        │ 15/11/2025 │ 80       │ [Ver][Edit][X]  ││
│ └──────────────────┴────────────┴────────────┴──────────┴─────────────────┘│
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Análisis de Margen
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     ANÁLISIS DE MARGEN                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Lista de Precios: [Lista Mayorista ▼]    [Analizar]                        │
│                                                                             │
│  Filtros: Proveedor [___▼]  Buscar [____________]                           │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│ ┌────────┬──────────┬──────────┬──────────┬──────────┬──────────┬─────────┐│
│ │ Código │ Nombre   │ Costo    │ Costo    │ Precio   │ Margen   │ Margen  ││
│ │        │          │ Neto     │ c/Imp    │ Venta    │ s/Neto   │ s/Final ││
│ ├────────┼──────────┼──────────┼──────────┼──────────┼──────────┼─────────┤│
│ │ COD001 │ Producto │ $8,500   │ $10,285  │ $15,000  │ 76.5%    │ 45.8%   ││
│ │ COD002 │ Otro     │ $12,300  │ $14,883  │ $18,000  │ 46.3%    │ 20.9%   ││
│ └────────┴──────────┴──────────┴──────────┴──────────┴──────────┴─────────┘│
│                                                                             │
│  Resumen:                                                                   │
│  - Artículos analizados: 150                                                │
│  - Margen promedio s/Neto: 52.3%                                            │
│  - Margen promedio s/Final: 28.7%                                           │
│  - Artículos con margen < 20%: 12 (⚠️)                                      │
│                                                                             │
│  [Exportar Excel]                                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 3.4 Fórmulas de Margen

```javascript
// Margen sobre Costo Neto (sin impuestos recuperables)
margenSobreNeto = ((precioVenta - costoNeto) / costoNeto) * 100;

// Margen sobre Costo Final (con impuestos)
margenSobreFinal = ((precioVenta - costoFinal) / costoFinal) * 100;

// Ejemplo:
// Costo Neto: $8,500
// Costo Final: $10,285
// Precio Venta: $15,000
// Margen s/Neto: (15000-8500)/8500 = 76.5%
// Margen s/Final: (15000-10285)/10285 = 45.8%
```

---

# 4. VARIACIÓN DE PRECIOS FOB

## 4.1 Descripción Funcional

Agregar columnas en "Último Costo por Artículo" para mostrar:
- FOB anterior del proveedor origen
- FOB anterior de la intermediaria
- Variación % en cada caso

## 4.2 Columnas a Agregar

| Columna | Descripción |
|---------|-------------|
| FOB Origen Ant. | Valor FOB del proveedor origen en el costeo anterior |
| Var % Origen | % variación del FOB origen |
| FOB Interm. Ant. | Valor FOB de la intermediaria en el costeo anterior |
| Var % Interm. | % variación del FOB intermediaria |

## 4.3 Lógica

```javascript
// En el endpoint /ultimos-costos, para cada artículo:

// Si hay costeo anterior:
const fobOrigenActual = articulo.valor_proveedor_origen;
const fobOrigenAnterior = articuloAnterior?.valor_proveedor_origen;
const varOrigenPct = fobOrigenAnterior ? 
    ((fobOrigenActual - fobOrigenAnterior) / fobOrigenAnterior) * 100 : null;

const fobIntermActual = articulo.valor_unitario_origen;
const fobIntermAnterior = articuloAnterior?.valor_unitario_origen;
const varIntermPct = fobIntermAnterior ? 
    ((fobIntermActual - fobIntermAnterior) / fobIntermAnterior) * 100 : null;
```

---

# 5. EXPORTAR EN LISTADO DE COSTEOS

## 5.1 Estado Actual

Existe el botón "Exportar" pero hay que verificar:
- ¿Qué exporta actualmente?
- ¿Funciona correctamente?
- ¿Qué información debería incluir?

## 5.2 Información Sugerida para Exportar

### Exportación del Listado (resumen):
| Columna | Descripción |
|---------|-------------|
| Nombre Costeo | Identificador |
| Proveedor | Proveedor de origen |
| Moneda | Moneda principal |
| Unidades | Total de unidades |
| Fecha Factura | Fecha de la factura |
| Fecha Despacho | Fecha de despacho |
| Tipo | Definitivo/Presupuesto |
| Costo Total | Inversión total |
| Costo Promedio | Costo unitario promedio |

### Exportación de Detalle (costeo completo):
- Datos generales
- Listado de artículos con cálculos
- Listado de gastos
- Totales

---

# 6. OCR DE COMPROBANTES

## 6.1 Análisis de Viabilidad

### Opción A: Integración con servicio externo
- **Google Cloud Vision API**: Muy preciso, costo por uso
- **Amazon Textract**: Especializado en documentos, costo por página
- **Microsoft Azure Form Recognizer**: Bueno para facturas, costo por uso

### Opción B: Solución local
- **Tesseract OCR**: Gratuito, open source, menos preciso
- Requiere entrenamiento para documentos específicos

### Opción C: Desarrollo separado (RECOMENDADO)
Crear una aplicación/herramienta auxiliar que:
1. Reciba imágenes/PDFs de comprobantes
2. Use OCR para extraer texto
3. Use IA (GPT/Claude) para interpretar y estructurar datos
4. Genere un archivo Excel con el formato de importación
5. Ese Excel se importa normalmente al sistema de costeo

## 6.2 Flujo Propuesto

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  Escanear   │───▶│   OCR       │───▶│   IA        │───▶│   Excel     │
│  documento  │    │   extrae    │    │   interpreta│    │   formato   │
│             │    │   texto     │    │   datos     │    │   importar  │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
                                                                │
                                                                ▼
                                                        ┌─────────────┐
                                                        │  Importar   │
                                                        │  al Sistema │
                                                        │  de Costeo  │
                                                        └─────────────┘
```

## 6.3 Implementación Sugerida

Dado que este desarrollo es complejo y puede ser independiente, sugiero:

1. **Fase 1**: Crear endpoint para subir comprobantes (solo almacenar)
2. **Fase 2**: Integrar OCR básico (Tesseract)
3. **Fase 3**: Agregar IA para interpretar (API de Claude/GPT)
4. **Fase 4**: Automatizar generación de pre-carga

---

# 7. CÁLCULO DE IMPUESTOS PARA LIBERACIÓN ADUANERA

## 7.1 Descripción Funcional

Calcular el monto total necesario para liberar mercadería en aduana, incluyendo todos los impuestos y tasas.

## 7.2 Componentes del Cálculo (A CONFIRMAR CON USUARIO)

### Items conocidos:
- Derechos de Importación
- Tasa de Estadística (3%)
- ANMAT (0.5% del FOB)

### Items a agregar (pendiente detalles del usuario):
- IVA (21%)
- IVA Adicional (según categoría)
- Impuesto a las Ganancias (según categoría)
- Ingresos Brutos (según provincia)
- Otros...

## 7.3 Diseño de Interfaz Propuesto

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                 CÁLCULO PARA LIBERACIÓN ADUANERA                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Costeo: [Seleccionar costeo ▼]    [Calcular]                              │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  DETALLE DE IMPUESTOS Y TASAS:                                              │
│                                                                             │
│  ┌────────────────────────────────────────┬──────────────┬────────────────┐│
│  │ Concepto                               │ Base         │ Importe        ││
│  ├────────────────────────────────────────┼──────────────┼────────────────┤│
│  │ Derechos de Importación (18%)          │ $1,500,000   │ $270,000       ││
│  │ Tasa de Estadística (3%)               │ $1,500,000   │ $45,000        ││
│  │ ANMAT (0.5%)                           │ $1,200,000   │ $6,000         ││
│  │ IVA (21%)                              │ $1,821,000   │ $382,410       ││
│  │ IVA Adicional (10.5%)                  │ $1,821,000   │ $191,205       ││
│  │ Impuesto a las Ganancias (6%)          │ $1,821,000   │ $109,260       ││
│  │ Ingresos Brutos (2.5%)                 │ $1,821,000   │ $45,525        ││
│  ├────────────────────────────────────────┼──────────────┼────────────────┤│
│  │ TOTAL A INGRESAR EN ADUANA             │              │ $1,049,400     ││
│  └────────────────────────────────────────┴──────────────┴────────────────┘│
│                                                                             │
│  [Exportar Detalle]                                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 7.4 Campos a Mostrar por Artículo

| Campo | Descripción |
|-------|-------------|
| Código | Código del artículo |
| Nombre | Nombre del artículo |
| Base Imponible | CIF + gastos para base aduana |
| Derechos | Importe de derechos |
| Estadística | Importe de estadística |
| ANMAT | Importe ANMAT |
| Subtotal Tributos | Suma de los anteriores |

---

# PLAN DE TRABAJO SUGERIDO

## Orden de Implementación

| Prioridad | Funcionalidad | Motivo |
|-----------|---------------|--------|
| 1 | Variación Precios FOB (#4) | Rápido, completa tabla existente |
| 2 | Exportar Listado (#5) | Rápido, verificar y completar |
| 3 | Revaluación de Costos (#1) | Alta utilidad, base para #2 |
| 4 | Consolidado de Costos (#2) | Depende de #1 |
| 5 | Cálculo Liberación (#7) | Pendiente detalles del usuario |
| 6 | Análisis de Márgenes (#3) | Requiere nueva estructura (listas) |
| 7 | OCR Comprobantes (#6) | Desarrollo separado, opcional |

---

# PRÓXIMOS PASOS INMEDIATOS

## Para Mañana:

1. **Verificar función Exportar** (#5)
   - Revisar código existente
   - Completar si falta algo

2. **Agregar Variación FOB** (#4)
   - Modificar endpoint /ultimos-costos
   - Agregar columnas en frontend

3. **Implementar Revaluación** (#1)
   - Agregar campos a modelo
   - Crear endpoint
   - Crear modal y funciones JS

4. **Discutir detalles de:**
   - Cálculo de liberación (#7) - qué items incluir
   - Análisis de márgenes (#3) - formato de listas de precios

---

**Documento preparado el:** 29 de Diciembre de 2025
**Estado:** Análisis y código preparado para desarrollo
