# MANUAL DE USUARIO
# SISTEMA DE COSTEO GOODIES

## Versión 1.0 - Diciembre 2025

---

# ÍNDICE

1. [Introducción](#1-introducción)
2. [Acceso al Sistema](#2-acceso-al-sistema)
3. [Pantalla Principal](#3-pantalla-principal)
4. [Cargar un Nuevo Costeo](#4-cargar-un-nuevo-costeo)
5. [Importar desde Excel](#5-importar-desde-excel)
6. [Editar un Costeo](#6-editar-un-costeo)
7. [Duplicar un Costeo](#7-duplicar-un-costeo)
8. [Calcular un Costeo](#8-calcular-un-costeo)
9. [Consultar Últimos Costos](#9-consultar-últimos-costos)
10. [Exportar Información](#10-exportar-información)
11. [Filtros y Búsquedas](#11-filtros-y-búsquedas)
12. [Preguntas Frecuentes](#12-preguntas-frecuentes)

---

# 1. INTRODUCCIÓN

## 1.1 ¿Qué es el Sistema de Costeo?

El Sistema de Costeo GOODIES es una aplicación web que permite gestionar los costeos de importación de mercadería. Con este sistema podrás:

- ✅ Cargar legajos de importación manualmente o desde Excel
- ✅ Calcular automáticamente todos los costos (FOB, CIF, derechos, IVA, etc.)
- ✅ Consultar el último costo de cada artículo
- ✅ Comparar costos actuales vs anteriores
- ✅ Exportar información a Excel
- ✅ Gestionar proveedores y empresas intermediarias

## 1.2 Requisitos

- Navegador web (Chrome, Firefox, Edge)
- Conexión a la red interna
- Usuario y contraseña del sistema

## 1.3 Soporte

Ante cualquier problema técnico, contactar al área de Sistemas.

---

# 2. ACCESO AL SISTEMA

## 2.1 Ingresar al Sistema

1. Abrir el navegador web
2. Escribir en la barra de direcciones: `http://localhost:3000`
3. Presionar Enter

![Pantalla de Login](Se mostrará la pantalla de inicio de sesión)

## 2.2 Iniciar Sesión

1. Ingresar tu **Email** (ejemplo: lpardina@goodies.com.ar)
2. Ingresar tu **Contraseña**
3. Hacer click en **"Iniciar Sesión"**

```
┌─────────────────────────────────────┐
│       Sistema de Costeo             │
│                                     │
│  Email: [________________]          │
│                                     │
│  Contraseña: [________________]     │
│                                     │
│  [    Iniciar Sesión    ]           │
│                                     │
└─────────────────────────────────────┘
```

## 2.3 Cerrar Sesión

1. En la esquina superior derecha, hacer click en **"Cerrar Sesión"**
2. Serás redirigido a la pantalla de login

> ⚠️ **IMPORTANTE:** Siempre cerrar sesión al terminar de trabajar, especialmente en computadoras compartidas.

---

# 3. PANTALLA PRINCIPAL

Una vez que inicies sesión, verás la pantalla principal con las siguientes secciones:

```
┌─────────────────────────────────────────────────────────────────┐
│  Sistema de Costeo                           [Usuario] [Salir]  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────┐  ┌──────────────────────┐            │
│  │ Importar/Cargar      │  │ Resumen              │            │
│  │ Legajo               │  │                      │            │
│  │                      │  │ Total Costeos: 25    │            │
│  │ [+ Carga Manual]     │  │ Presupuestos: 5      │            │
│  │ [Importar Excel]     │  │                      │            │
│  └──────────────────────┘  └──────────────────────┘            │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────────┤
│  │ Listado de Costeos                                          │
│  │                                                              │
│  │ Filtros: [Proveedor ▼] [Tipo ▼] [Solo última versión]       │
│  │                                                              │
│  │ ┌────┬────────┬──────────┬───────┬─────────┬──────┬───────┐ │
│  │ │ ☐  │ Nombre │ Proveedor│ Moneda│ Fecha F.│ Tipo │Acciones│ │
│  │ ├────┼────────┼──────────┼───────┼─────────┼──────┼───────┤ │
│  │ │ ☐  │ KB 1-25│ STABZ    │ USD   │ 15/01/25│ Def. │ ...   │ │
│  │ └────┴────────┴──────────┴───────┴─────────┴──────┴───────┘ │
│  └─────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────────┤
│  │ Último Costo por Artículo                                   │
│  │                                                              │
│  │ Buscar: [______________] Proveedor: [Todos ▼]               │
│  │                                                              │
│  │ ┌────────┬──────────┬────────┬────────┬─────────┬──────────┐│
│  │ │ Código │ Proveedor│ Nombre │Costo   │Costo Ant│ Dif %    ││
│  │ ├────────┼──────────┼────────┼────────┼─────────┼──────────┤│
│  │ │ COD001 │ STABZ    │ Produc │$10,500 │ $9,800  │ +7.14%   ││
│  │ └────────┴──────────┴────────┴────────┴─────────┴──────────┘│
│  └─────────────────────────────────────────────────────────────┘
└─────────────────────────────────────────────────────────────────┘
```

## 3.1 Sección "Importar / Cargar Legajo"

Desde aquí podés:
- **+ Carga Manual:** Cargar un nuevo costeo completando los datos manualmente
- **Importar Excel:** Cargar un costeo desde un archivo Excel

## 3.2 Sección "Resumen"

Muestra estadísticas generales:
- **Total Costeos:** Cantidad total de costeos cargados
- **Presupuestos:** Cantidad de costeos que aún no son definitivos

## 3.3 Sección "Listado de Costeos"

Tabla con todos tus costeos, incluyendo:
- Nombre del costeo
- Proveedor
- Moneda
- Unidades
- Fechas
- Tipo (Definitivo o Presupuesto)
- Botones de acciones

## 3.4 Sección "Último Costo por Artículo"

Consulta rápida del último costo de cada artículo, con comparación vs el costo anterior.

---

# 4. CARGAR UN NUEVO COSTEO

## 4.1 Iniciar Carga Manual

1. Hacer click en el botón **"+ Carga Manual"**
2. Se abrirá una ventana con 4 pestañas (tabs)

## 4.2 Tab 1: Datos Generales

Completar los siguientes campos:

### Datos Obligatorios:
| Campo | Descripción | Ejemplo |
|-------|-------------|---------|
| Nombre del Costeo | Identificador único | BACKUS 1-25 |
| Proveedor de Origen | Nombre del proveedor | STABZ |
| Moneda Principal | Moneda de la factura | USD, EUR, GBP |

### Datos de Empresa Intermediaria (opcional):
Si la importación pasa por una empresa intermediaria:

1. Marcar el checkbox **"Tiene Empresa Intermediaria"**
2. Completar:
   - Nombre Empresa Intermediaria
   - Nro Factura Intermediaria
   - Fecha Factura Intermediaria
   - Fecha Vencimiento Intermediaria

### Datos de Factura:
| Campo | Descripción |
|-------|-------------|
| Factura Nro | Número de la factura |
| Monto Factura | Monto total |
| Fecha Factura | Fecha de emisión |
| Fecha Vencimiento | Fecha de vencimiento |
| Fecha Despacho | Fecha de despacho aduanero |

### Tipos de Cambio:
| Campo | Descripción |
|-------|-------------|
| TC USD | Tipo de cambio del dólar |
| TC EUR | Tipo de cambio del euro |
| TC GBP | Tipo de cambio de la libra |

3. Hacer click en **"Siguiente →"**

## 4.3 Tab 2: Base Aduana

Completar los valores para el cálculo de la base imponible:

| Campo | Moneda | Monto |
|-------|--------|-------|
| Puesta FOB | Seleccionar | Ingresar monto |
| Flete Aduana | Seleccionar | Ingresar monto |
| Seguro Aduana | Seleccionar | Ingresar monto |

Hacer click en **"Siguiente →"**

## 4.4 Tab 3: Artículos

### Agregar artículos manualmente:

1. Hacer click en **"+ Agregar Artículo"**
2. Completar cada columna:

| Columna | Descripción |
|---------|-------------|
| Cod. Goodies | Código interno del artículo |
| Cod. Proveedor | Código del proveedor |
| Nombre | Nombre del artículo |
| Cajas | Cantidad de cajas |
| Und/Caja | Unidades por caja |
| Valor Origen | Valor unitario del proveedor original |
| Valor Interm. | Valor de la intermediaria (si aplica) |
| % Derecho | Porcentaje de derechos de importación |
| % Imp.Int. | Porcentaje de impuesto interno |

3. Repetir para cada artículo
4. Para eliminar un artículo, hacer click en **"X"**

### Importar artículos desde Excel:

1. Hacer click en **"📥 Descargar Template"** para obtener el formato
2. Completar el archivo con los datos
3. Hacer click en **"📤 Importar desde Excel"**
4. Seleccionar el archivo

### Calcular Valor Intermediaria automáticamente:

Si tenés empresa intermediaria y conocés el % de margen:

1. Completar el **"Valor Origen"** de cada artículo
2. Ingresar el **"% Margen"** (ej: 20)
3. Hacer click en **"Calcular Valores Intermediaria"**
4. El sistema calculará: `Valor Interm = Valor Origen / (1 - %Margen/100)`

> 💡 **Ejemplo:** Si Valor Origen = $100 y Margen = 20%, entonces Valor Interm = $100 / 0.80 = $125

Hacer click en **"Siguiente →"**

## 4.5 Tab 4: Gastos

### Agregar gastos manualmente:

1. Hacer click en **"+ Agregar Gasto"**
2. Completar cada columna:

| Columna | Descripción |
|---------|-------------|
| Descripción | Tipo de gasto (Flete, Despachante, etc.) |
| Proveedor | Proveedor del servicio |
| Nro Comprob. | Número de comprobante (vacío = ESTIMADO) |
| Moneda | USD, EUR, GBP, ARS |
| Monto | Importe del gasto |
| % Recargo | Porcentaje de recargo (si aplica) |
| Observaciones | Notas adicionales |

3. Repetir para cada gasto
4. Para eliminar un gasto, hacer click en **"X"**

### Importar gastos desde Excel:

1. Hacer click en **"📥 Descargar Template"**
2. Completar el archivo
3. Hacer click en **"📤 Importar desde Excel"**
4. Seleccionar el archivo

## 4.6 Guardar el Costeo

1. Verificar que todos los datos estén correctos
2. Hacer click en **"💾 Guardar Costeo"**
3. Aparecerá mensaje de confirmación
4. El costeo aparecerá en el listado

> ⚠️ **IMPORTANTE:** Después de guardar, debes hacer click en **"Calc"** para ejecutar los cálculos.

---

# 5. IMPORTAR DESDE EXCEL

## 5.1 Preparar el Archivo Excel

El archivo Excel debe tener 3 hojas con los siguientes nombres exactos:
- **DATOS_GENERALES**
- **ARTICULOS**
- **BASE_ADUANA_GASTOS**

## 5.2 Importar el Archivo

1. Hacer click en **"Importar Excel"**
2. Se desplegará el área de carga
3. Arrastrar el archivo Excel al área punteada, o hacer click para seleccionar
4. Verificar que aparezca el nombre del archivo
5. Hacer click en **"Importar"**

```
┌─────────────────────────────────────┐
│                                     │
│            📁                       │
│                                     │
│   Arrastra tu archivo Excel aquí    │
│                                     │
│   archivo_legajo.xlsx              │
│                                     │
│   [        Importar        ]        │
│                                     │
└─────────────────────────────────────┘
```

## 5.3 Revisar y Modificar

1. Al importar, se abrirá la ventana de **Carga Manual** con los datos pre-cargados
2. Revisar cada pestaña (Datos Generales, Base Aduana, Artículos, Gastos)
3. Modificar lo que sea necesario
4. Hacer click en **"💾 Guardar Costeo"**

> 💡 **TIP:** El sistema lee tanto el formato nuevo como el formato viejo de legajos.

---

# 6. EDITAR UN COSTEO

## 6.1 Abrir para Edición

1. Buscar el costeo en el **Listado de Costeos**
2. Hacer click en el botón **"Edit"** (azul)

```
┌────────────────────────────────────────────────────────┐
│ KB 1-25 │ STABZ │ USD │ ... │ [Calc][Edit][Dup][...] │
└────────────────────────────────────────────────────────┘
                              ↑
                        Click aquí
```

## 6.2 Modificar Datos

1. Se abrirá la ventana de Carga Manual con todos los datos cargados
2. Navegar entre las pestañas
3. Modificar los campos necesarios
4. Hacer click en **"💾 Guardar Costeo"**

> ⚠️ **IMPORTANTE:** Si modificaste valores, deberás recalcular haciendo click en **"Calc"**

---

# 7. DUPLICAR UN COSTEO

## 7.1 ¿Cuándo usar esta función?

Usar cuando:
- Llega un nuevo legajo del mismo proveedor
- Los artículos son similares al costeo anterior
- Querés ahorrar tiempo de carga

## 7.2 Duplicar

1. Buscar el costeo que querés usar como base
2. Hacer click en el botón **"Dup"** (violeta)

```
┌────────────────────────────────────────────────────────┐
│ KB 1-25 │ STABZ │ USD │ ... │ [Calc][Edit][Dup][...] │
└────────────────────────────────────────────────────────┘
                                    ↑
                              Click aquí
```

## 7.3 Completar el Nuevo Costeo

1. Se abrirá la ventana de Carga Manual con:
   - Nombre: "NOMBRE ORIGINAL - COPIA"
   - Proveedor y estructura de artículos copiados
   - **Campos vacíos:** fechas, valores, montos de gastos

2. Modificar el **Nombre** del costeo (ej: "KB 2-25")
3. Completar las **fechas** nuevas
4. Completar los **valores** de artículos
5. Completar los **montos** de gastos
6. Hacer click en **"💾 Guardar Costeo"**

> 💡 **TIP:** Solo tenés que completar lo que cambió, la estructura ya está armada.

---

# 8. CALCULAR UN COSTEO

## 8.1 ¿Cuándo calcular?

Calcular después de:
- Cargar un nuevo costeo
- Modificar un costeo existente
- Corregir valores

## 8.2 Ejecutar Cálculo

1. Buscar el costeo en el listado
2. Hacer click en el botón **"Calc"** (amarillo)

```
┌────────────────────────────────────────────────────────┐
│ KB 1-25 │ STABZ │ USD │ ... │ [Calc][Edit][Dup][...] │
└────────────────────────────────────────────────────────┘
                              ↑
                        Click aquí
```

3. Confirmar la acción
4. Esperar el mensaje de confirmación con el **Costo Total**

## 8.3 Verificar Resultados

1. Hacer click en el botón **"Ver"** (gris)
2. Se mostrará un resumen con:
   - Proveedor
   - Factura
   - Moneda
   - Tipos de cambio
   - Unidades
   - Total gastos
   - **INVERSIÓN TOTAL**

---

# 9. CONSULTAR ÚLTIMOS COSTOS

## 9.1 Ubicación

La sección **"Último Costo por Artículo"** está debajo del Listado de Costeos.

## 9.2 Información Mostrada

| Columna | Descripción |
|---------|-------------|
| Código | Código Goodies del artículo |
| Proveedor | Proveedor del último costeo |
| Nombre | Nombre del artículo |
| Mon. FOB | Moneda del valor FOB |
| Valor FOB | Valor unitario FOB |
| Costo Neto | Costo unitario sin impuestos |
| Costo c/Imp | Costo unitario con IVA e impuestos |
| Costo Ant. | Costo del costeo anterior |
| Dif % | Diferencia porcentual |
| Fecha Desp. | Fecha de despacho |
| Costeo | Nombre del costeo origen |
| TC | Tipos de cambio utilizados |

## 9.3 Interpretar la Diferencia %

| Color | Significado |
|-------|-------------|
| 🔴 Rojo | El costo AUMENTÓ respecto al anterior |
| 🟢 Verde | El costo DISMINUYÓ respecto al anterior |
| ⚪ Blanco | Sin cambio o sin dato anterior |

**Ejemplo:**
- Costo actual: $10,500
- Costo anterior: $9,800
- Diferencia: +7.14% (rojo = aumentó)

## 9.4 Buscar un Artículo

1. Escribir en el campo **"Buscar Artículo"**
2. Podés buscar por código o por nombre
3. Los resultados se filtran automáticamente

## 9.5 Filtrar por Proveedor

1. Seleccionar un proveedor en el dropdown **"Proveedor"**
2. Se mostrarán solo los artículos de ese proveedor
3. Seleccionar "Todos" para ver todos

---

# 10. EXPORTAR INFORMACIÓN

## 10.1 Exportar Costeo Calculado

Para exportar un costeo con todos los cálculos:

1. Buscar el costeo en el listado
2. Hacer click en el botón **"Excel"** (verde)
3. Se descargará un archivo Excel

## 10.2 Exportar Legajo Completo

Para exportar todos los datos de carga (sin cálculos):

1. Buscar el costeo en el listado
2. Hacer click en el botón **"Leg"** (gris)
3. Se descargará un archivo con:
   - Datos Generales
   - Artículos
   - Gastos

> 💡 **TIP:** El archivo de legajo sirve como respaldo de los datos cargados.

## 10.3 Exportar Últimos Costos

Para exportar la tabla de últimos costos:

1. Ir a la sección **"Último Costo por Artículo"**
2. Aplicar filtros si es necesario
3. Hacer click en **"Exportar Excel"**
4. Se descargará un archivo con todos los artículos mostrados

---

# 11. FILTROS Y BÚSQUEDAS

## 11.1 Filtros del Listado de Costeos

### Filtrar por Proveedor:
1. Seleccionar un proveedor en el dropdown
2. Se mostrarán solo los costeos de ese proveedor

### Filtrar por Tipo:
1. Seleccionar "Definitivo" o "Presupuesto"
2. **Definitivo:** Tiene fecha de factura Y fecha de despacho
3. **Presupuesto:** Falta alguna de las dos fechas

### Solo Última Versión:
1. Marcar el checkbox **"Solo última versión"**
2. Seleccionar el criterio:
   - Por fecha de carga
   - Por fecha de factura
   - Por fecha de despacho
3. Se mostrará solo el costeo más reciente de cada proveedor

### Limpiar Filtros:
1. Hacer click en el botón **"Limpiar"**
2. Se quitarán todos los filtros aplicados

## 11.2 Selección Múltiple

### Seleccionar costeos:
1. Marcar el checkbox de cada costeo que querés seleccionar
2. O marcar el checkbox del encabezado para seleccionar todos

### Acciones masivas:
Cuando hay costeos seleccionados, aparece una barra con:
- **Cantidad seleccionados**
- **Exportar:** Exportar los seleccionados
- **Recalcular TC:** Recalcular con nuevos tipos de cambio

---

# 12. PREGUNTAS FRECUENTES

## 12.1 ¿Por qué mi costeo aparece como "Presupuesto"?

**Respuesta:** Un costeo es "Definitivo" solo cuando tiene:
- ✅ Fecha de Factura
- ✅ Fecha de Despacho

Si falta alguna de las dos, aparecerá como "Presupuesto".

**Solución:** Editar el costeo y completar las fechas faltantes.

---

## 12.2 ¿Por qué el Costo Neto aparece en "$-"?

**Respuesta:** El costeo no fue calculado.

**Solución:** Hacer click en el botón **"Calc"** del costeo.

---

## 12.3 ¿Cómo sé si tengo que usar Empresa Intermediaria?

**Respuesta:** Usar cuando:
- La mercadería se compra a través de un trader
- Hay una factura del proveedor original Y otra de la intermediaria
- El valor de la intermediaria es diferente al del proveedor original

---

## 12.4 ¿Qué es el "Valor Origen" vs "Valor Intermediaria"?

| Campo | Descripción |
|-------|-------------|
| Valor Origen | Precio que cobra el fabricante/proveedor original |
| Valor Intermediaria | Precio que cobra el trader/intermediario |

Si NO hay intermediaria, ambos valores son iguales.

---

## 12.5 ¿Cómo calculo el margen de la intermediaria?

**Fórmula:** `Margen = 1 - (Valor Origen / Valor Intermediaria)`

**Ejemplo:**
- Valor Origen: $100
- Valor Intermediaria: $125
- Margen = 1 - (100/125) = 1 - 0.80 = 0.20 = **20%**

---

## 12.6 ¿Por qué no me deja editar "Valor Interm."?

**Respuesta:** El campo solo es editable si marcaste **"Tiene Empresa Intermediaria"**.

**Solución:**
1. Ir a Tab 1: Datos Generales
2. Marcar el checkbox "Tiene Empresa Intermediaria"
3. Volver a Tab 3: Artículos
4. Ahora podrás editar el campo

---

## 12.7 ¿Qué pasa si importo un Excel con formato viejo?

**Respuesta:** El sistema reconoce automáticamente ambos formatos:
- Formato nuevo (7 columnas de gastos)
- Formato viejo (4 columnas de gastos)

No necesitás hacer nada especial.

---

## 12.8 ¿Por qué la "Dif %" aparece en rojo?

**Respuesta:** El color indica:
- 🔴 **Rojo:** El costo AUMENTÓ (malo)
- 🟢 **Verde:** El costo DISMINUYÓ (bueno)

---

## 12.9 ¿Cómo actualizo un costeo que ya guardé?

**Pasos:**
1. Hacer click en **"Edit"**
2. Modificar los datos necesarios
3. Hacer click en **"💾 Guardar Costeo"**
4. Hacer click en **"Calc"** para recalcular

---

## 12.10 ¿Puedo eliminar un costeo?

**Sí.** 
1. Hacer click en el botón **"X"** (rojo)
2. Confirmar la eliminación

> ⚠️ **CUIDADO:** Esta acción no se puede deshacer.

---

## 12.11 ¿Cómo hago una copia de seguridad de un costeo?

**Opción 1:** Exportar el legajo
1. Hacer click en **"Leg"**
2. Guardar el archivo Excel

**Opción 2:** Duplicar el costeo
1. Hacer click en **"Dup"**
2. Guardar con otro nombre (ej: "KB 1-25 - BACKUP")

---

## 12.12 ¿El sistema guarda automáticamente?

**No.** Siempre debes hacer click en **"💾 Guardar Costeo"** para guardar los cambios.

---

# ANEXO: ATAJOS Y TIPS

## Tips de Productividad

| Acción | Tip |
|--------|-----|
| Cargar costeo similar | Usar **"Dup"** del costeo anterior |
| Verificar datos antes de guardar | Revisar todas las pestañas |
| Buscar artículo rápido | Escribir código o nombre parcial |
| Comparar precios | Mirar columna "Dif %" |
| Backup de datos | Exportar con botón "Leg" |

## Significado de los Botones

| Botón | Color | Función |
|-------|-------|---------|
| Calc | 🟡 Amarillo | Calcular costeo |
| Edit | 🔵 Azul | Editar costeo |
| Dup | 🟣 Violeta | Duplicar costeo |
| Leg | ⚪ Gris | Exportar legajo |
| Ver | ⚪ Gris | Ver detalle |
| Excel | 🟢 Verde | Exportar calculado |
| X | 🔴 Rojo | Eliminar |

## Significado de los Colores de Estado

| Estado | Significado |
|--------|-------------|
| 🟢 Definitivo | Costeo completo (tiene fecha factura y despacho) |
| 🟠 Presupuesto | Costeo incompleto (falta alguna fecha) |

---

**FIN DEL MANUAL**

---

*Manual de Usuario v1.0*
*Sistema de Costeo GOODIES*
*Diciembre 2025*
