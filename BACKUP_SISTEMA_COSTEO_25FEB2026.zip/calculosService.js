const { Costeo, ArticuloCosteo, GastosAduana, GastosVarios, ConsolidadoProveedor } = require('../models');

class CalculosService {

    static async calcularCosteo(costeoId) {
        try {
            const costeo = await Costeo.findByPk(costeoId, {
                include: [
                    { model: ArticuloCosteo, as: 'articulos' },
                    { model: GastosAduana, as: 'gastos_aduana' },
                    { model: GastosVarios, as: 'gastos_varios' },
                    { model: ConsolidadoProveedor, as: 'proveedores_consolidado' }
                ]
            });

            if (!costeo) {
                throw new Error('Costeo no encontrado');
            }

            const tc_usd = parseFloat(costeo.tc_usd) || 1;
            const tc_eur = parseFloat(costeo.tc_eur) || tc_usd;
            const tc_gbp = parseFloat(costeo.tc_gbp) || tc_usd;

            const monedaPrincipal = (costeo.moneda_principal || 'USD').toUpperCase();
            let tcPrincipal = tc_usd;
            if (monedaPrincipal === 'EUR') {
                tcPrincipal = tc_eur;
            } else if (monedaPrincipal === 'GBP') {
                tcPrincipal = tc_gbp;
            }

            const articulos = costeo.articulos || [];
            const gastosVarios = costeo.gastos_varios || [];
            const proveedoresConsolidado = costeo.proveedores_consolidado || [];

            const esConsolidado = costeo.es_consolidado === true;
            let participacionPorFOB = 1;
            let participacionPorVolumen = 1;
            let participacionPorPeso = 1;

            if (esConsolidado && proveedoresConsolidado.length > 0) {
                const montoFactura = parseFloat(costeo.monto_factura) || 0;
                let fobProveedorActual;
                if (montoFactura > 0) {
                    fobProveedorActual = montoFactura * tcPrincipal;
                } else {
                    const fobProveedorActualDivisa = articulos.reduce((sum, art) => {
                        return sum + (parseFloat(art.importe_total_origen) || 0);
                    }, 0);
                    fobProveedorActual = fobProveedorActualDivisa * tcPrincipal;
                }
                const volumenActual = parseFloat(costeo.volumen_m3) || 0;
                const pesoActual = parseFloat(costeo.peso_kg) || 0;

                let fobOtrosProveedores = 0;
                let volumenOtros = 0;
                let pesoOtros = 0;

                for (const prov of proveedoresConsolidado) {
                    let fobProv = parseFloat(prov.fob_total) || 0;
                    const monedaProv = (prov.moneda || 'USD').toUpperCase();
                    
                    let tcProv = tc_usd;
                    if (monedaProv === 'EUR') tcProv = tc_eur;
                    else if (monedaProv === 'GBP') tcProv = tc_gbp;
                    
                    fobOtrosProveedores += fobProv * tcProv;
                    volumenOtros += parseFloat(prov.volumen_m3) || 0;
                    pesoOtros += parseFloat(prov.peso_kg) || 0;
                }

                const fobTotalConsolidado = fobProveedorActual + fobOtrosProveedores;
                const volumenTotalConsolidado = volumenActual + volumenOtros;
                const pesoTotalConsolidado = pesoActual + pesoOtros;

                participacionPorFOB = fobTotalConsolidado > 0 ? fobProveedorActual / fobTotalConsolidado : 1;
                participacionPorVolumen = volumenTotalConsolidado > 0 ? volumenActual / volumenTotalConsolidado : 1;
                participacionPorPeso = pesoTotalConsolidado > 0 ? pesoActual / pesoTotalConsolidado : 1;
            }

            let fobTotalPesos = 0;
            let fobTotalDivisa = 0;
            const fobPorGrupo = {};
            let fobArticulosConAnmat = 0;

            for (const art of articulos) {
                const importeOrigen = parseFloat(art.importe_total_origen) || 0;                const fobArtPesos = importeOrigen * tcPrincipal;
                const grupo = art.grupo || '';
                const aplicaAnmat = art.aplica_anmat !== false;

                fobTotalDivisa += importeOrigen;
                fobTotalPesos += fobArtPesos;

                if (!fobPorGrupo[grupo]) {
                    fobPorGrupo[grupo] = 0;
                }
                fobPorGrupo[grupo] += fobArtPesos;

                if (aplicaAnmat) {
                    fobArticulosConAnmat += fobArtPesos;
                }
            }

            // === VERIFICACIÓN: suma artículos vs monto factura ===
            const montoFactura = parseFloat(costeo.monto_factura) || 0;
            let avisos = [];
            if (montoFactura > 0) {
                const diferencia = Math.abs(fobTotalDivisa - montoFactura);
                const tolerancia = montoFactura * 0.01; // 1% de tolerancia por redondeos
                if (diferencia > tolerancia) {
                    avisos.push(
                        'ATENCIÓN: La suma de artículos (' + fobTotalDivisa.toFixed(2) + ' ' + monedaPrincipal + 
                        ') NO coincide con el monto factura (' + montoFactura.toFixed(2) + ' ' + monedaPrincipal + 
                        '). Diferencia: ' + diferencia.toFixed(2) + ' ' + monedaPrincipal
                    );
                }
            }

            // === BASE ADUANA ===
            // Componente 1: FOB Factura (suma artículos) - ya calculado como fobTotalPesos
            // Componente 2: Puesta FOB (tab Base Aduana)
            // Componente 3: Flete Aduana (tab Base Aduana)
            // Componente 4: Seguro Aduana (tab Base Aduana)

            let puestaFob = parseFloat(costeo.fob_monto) || 0;
            let fleteAduana = parseFloat(costeo.flete_monto) || 0;
            let seguroAduana = parseFloat(costeo.seguro_monto) || 0;
            
            if (esConsolidado) {
                puestaFob = parseFloat(costeo.fob_parte) || 0;
                fleteAduana = parseFloat(costeo.flete_parte) || 0;
                seguroAduana = parseFloat(costeo.seguro_parte) || 0;
            }

            // Convertir Puesta FOB a ARS según su moneda
            const fobMonedaBase = (costeo.fob_moneda || monedaPrincipal).toUpperCase();
            let tcFobBase = tc_usd;
            if (fobMonedaBase === 'EUR') tcFobBase = tc_eur;
            else if (fobMonedaBase === 'GBP') tcFobBase = tc_gbp;
            const puestaFobARS = puestaFob * tcFobBase;

            // Convertir Flete a ARS según su moneda
            const fleteMoneda = (costeo.flete_moneda || 'USD').toUpperCase();
            let tcFlete = tc_usd;
            if (fleteMoneda === 'EUR') tcFlete = tc_eur;
            else if (fleteMoneda === 'GBP') tcFlete = tc_gbp;
            const fleteAduanaARS = fleteAduana * tcFlete;

            // Convertir Seguro a ARS según su moneda
            const seguroMoneda = (costeo.seguro_moneda || 'USD').toUpperCase();
            let tcSeguro = tc_usd;
            if (seguroMoneda === 'EUR') tcSeguro = tc_eur;
            else if (seguroMoneda === 'GBP') tcSeguro = tc_gbp;
            const seguroAduanaARS = seguroAduana * tcSeguro;

            // Base Aduana Total = FOB Factura + Puesta FOB + Flete + Seguro (todo en ARS)
            const gastosBaseAduanaARS = puestaFobARS + fleteAduanaARS + seguroAduanaARS;
            const baseAduanaTotalARS = fobTotalPesos + gastosBaseAduanaARS;

            const gastosPorGrupo = {};
            let totalGastosVariosPesos = 0;

            for (const gasto of gastosVarios) {
                const montoOriginal = parseFloat(gasto.monto) || 0;
                const monedaGasto = (gasto.moneda || 'USD').toUpperCase();
                const recargo = parseFloat(gasto.recargo) || 0;

                let tcGasto = 1;
                if (monedaGasto === 'USD') {
                    tcGasto = tc_usd;
                } else if (monedaGasto === 'EUR') {
                    tcGasto = tc_eur || tc_usd;
                } else if (monedaGasto === 'GBP') {
                    tcGasto = tc_gbp || tc_usd;
                } else if (monedaGasto === 'ARS') {
                    tcGasto = 1;
                }

                let montoOriginalARS = montoOriginal * tcGasto;
                if (recargo > 0) {
                    montoOriginalARS = montoOriginalARS * (1 + recargo / 100);
                }

                let montoProrrateado = montoOriginalARS;

                if (esConsolidado) {
                    const metodo = gasto.metodo_prorrateo || 'por_fob';
                    
                    if (metodo === 'por_fob') {
                        montoProrrateado = montoOriginalARS * participacionPorFOB;
                    } else if (metodo === 'por_volumen') {
                        montoProrrateado = montoOriginalARS * participacionPorVolumen;
                    } else if (metodo === 'por_peso') {
                        montoProrrateado = montoOriginalARS * participacionPorPeso;
                    }
                }

                await gasto.update({ 
                    monto_ars: montoOriginalARS,
                    monto_prorrateado: montoProrrateado 
                });

                totalGastosVariosPesos += montoProrrateado;

                const grupoGasto = gasto.grupo || '';
                if (!gastosPorGrupo[grupoGasto]) {
                    gastosPorGrupo[grupoGasto] = 0;
                }
                gastosPorGrupo[grupoGasto] += montoProrrateado;
            }

            let totalDerechosARS = 0;
            let totalEstadisticaARS = 0;
            let totalIVA_ARS = 0;
            let totalImpuestoInternoARS = 0;
            let totalAnmatARS = 0;
            let totalCostoNetoARS = 0;
            let unidadesTotales = 0;

            const articulosActualizados = [];

            for (const articulo of articulos) {
                const importeOrigen = parseFloat(articulo.importe_total_origen) || 0;
                const unidades = parseInt(articulo.unidades_totales) || 1;
                const derechosPctRaw = parseFloat(articulo.derechos_porcentaje) || 0;
                const impInternosPctRaw = parseFloat(articulo.impuesto_interno_porcentaje) || 0;
                const derechosPct = derechosPctRaw > 1 ? derechosPctRaw / 100 : derechosPctRaw;
                const impInternosPct = impInternosPctRaw > 1 ? impInternosPctRaw / 100 : impInternosPctRaw;
                const grupoArticulo = articulo.grupo || '';
                const aplicaAnmat = articulo.aplica_anmat !== false;

                const fobTotalArtPesos = importeOrigen * tcPrincipal;
                const fobUnitarioPesos = fobTotalArtPesos / unidades;
                const fobUnitarioDivisa = importeOrigen / unidades;

                const participacionFOB = fobTotalPesos > 0 ? fobTotalArtPesos / fobTotalPesos : 0;

                let anmatARS = 0;
                if (aplicaAnmat && fobArticulosConAnmat > 0) {
                    anmatARS = fobTotalArtPesos * 0.005;
                }

                const gastosBaseAduanaArt = gastosBaseAduanaARS * participacionFOB;
                const baseAduana = fobTotalArtPesos + gastosBaseAduanaArt;

                const derechosARS = derechosPct > 0 ? baseAduana * derechosPct : 0;
                const estadisticaARS = derechosPct > 0 ? baseAduana * 0.03 : 0;

                let gastosVariosArt = 0;
                const gastosGenerales = gastosPorGrupo[''] || 0;
                gastosVariosArt += gastosGenerales * participacionFOB;

                for (const [grupoGasto, montoGasto] of Object.entries(gastosPorGrupo)) {
                    if (grupoGasto !== '' && grupoGasto === grupoArticulo) {
                        const fobDelGrupo = fobPorGrupo[grupoArticulo] || 0;
                        if (fobDelGrupo > 0) {
                            const participacionEnGrupo = fobTotalArtPesos / fobDelGrupo;
                            gastosVariosArt += montoGasto * participacionEnGrupo;
                        }
                    }
                }

                const costoTotalNetoARS = fobTotalArtPesos + anmatARS + derechosARS + estadisticaARS + gastosVariosArt;
                const costoUnitarioNetoARS = costoTotalNetoARS / unidades;

                const impuestoInternoUnitARS = costoUnitarioNetoARS * impInternosPct;
                const impuestoInternoTotalARS = impuestoInternoUnitARS * unidades;

                const ivaUnitarioARS = costoUnitarioNetoARS * 0.21;
                const ivaTotalARS = ivaUnitarioARS * unidades;

                const costoUnitarioFinalARS = costoUnitarioNetoARS + impuestoInternoUnitARS + ivaUnitarioARS;
                const costoTotalFinalARS = costoUnitarioFinalARS * unidades;

                const factorImportacion = fobUnitarioPesos > 0 ?
                    ((costoUnitarioNetoARS - fobUnitarioPesos) / fobUnitarioPesos) * 100 : 0;

                totalAnmatARS += anmatARS;
                totalDerechosARS += derechosARS;
                totalEstadisticaARS += estadisticaARS;
                totalIVA_ARS += ivaTotalARS;
                totalImpuestoInternoARS += impuestoInternoTotalARS;
                totalCostoNetoARS += costoTotalNetoARS;
                unidadesTotales += unidades;

                await articulo.update({
                    participacion_fob: participacionFOB,
                    fob_unitario_usd: fobUnitarioDivisa,
                    fob_total_usd: importeOrigen,
                    fob_unitario_ars: fobUnitarioPesos,
                    fob_total_ars: fobTotalArtPesos,
                    anmat_ars: anmatARS,
                    gastos_base_aduana_ars: gastosBaseAduanaArt,
                    base_aduana_ars: baseAduana,
                    derechos_total_ars: derechosARS,
                    estadistica_total_ars: estadisticaARS,
                    gastos_varios_ars: gastosVariosArt,
                    costo_total_neto_ars: costoTotalNetoARS,
                    costo_unitario_neto_ars: costoUnitarioNetoARS,
                    iva_unitario_ars: ivaUnitarioARS,
                    iva_total_ars: ivaTotalARS,
                    impuesto_interno_unitario_ars: impuestoInternoUnitARS,
                    impuesto_interno_total_ars: impuestoInternoTotalARS,
                    costo_unitario_ars: costoUnitarioFinalARS,
                    costo_total_ars: costoTotalFinalARS,
                    factor_importacion: factorImportacion
                });

                articulosActualizados.push({
                    codigo: articulo.codigo_goodies,
                    nombre: articulo.nombre,
                    unidades: unidades,
                    costo_unitario_neto: costoUnitarioNetoARS,
                    costo_unitario_final: costoUnitarioFinalARS,
                    factor_importacion: factorImportacion
                });
            }

            const totalTributosARS = totalDerechosARS + totalEstadisticaARS + totalIVA_ARS + totalImpuestoInternoARS;
            const costoTotalFinalARS = totalCostoNetoARS + totalIVA_ARS + totalImpuestoInternoARS;

            await costeo.update({
                fob_total_usd: fobTotalDivisa,
                fob_total_ars: fobTotalPesos,
                anmat_total_ars: totalAnmatARS,
                derechos_total_ars: totalDerechosARS,
                estadistica_ars: totalEstadisticaARS,
                iva_ars: totalIVA_ARS,
                impuesto_interno_ars: totalImpuestoInternoARS,
                total_tributos_ars: totalTributosARS,
                total_gastos_ars: totalGastosVariosPesos,
                costo_total_neto_ars: totalCostoNetoARS,
                costo_total_ars: costoTotalFinalARS,
                unidades_totales: unidadesTotales,
                estado: 'calculado'
            });

            return {
                exito: true,
                costeo_id: costeoId,
                es_consolidado: esConsolidado,
                avisos: avisos,
                resumen: {
                    fob_total_pesos: fobTotalPesos.toFixed(2),
                    gastos_varios_ars: totalGastosVariosPesos.toFixed(2),
                    costo_total_neto_ars: totalCostoNetoARS.toFixed(2),
                    costo_total_final_ars: costoTotalFinalARS.toFixed(2),
                    unidades_totales: unidadesTotales
                },
                articulos: articulosActualizados
            };

        } catch (error) {
            console.error('Error en calculos:', error);
            throw error;
        }
    }

  static async previewConsolidado(costeoId) {
        try {
            const costeo = await Costeo.findByPk(costeoId, {
                include: [
                    { model: ArticuloCosteo, as: 'articulos' },
                    { model: GastosVarios, as: 'gastos_varios' },
                    { model: ConsolidadoProveedor, as: 'proveedores_consolidado' }
                ]
            });

            if (!costeo) {
                throw new Error('Costeo no encontrado');
            }

            if (!costeo.es_consolidado) {
                return { es_consolidado: false };
            }

            const articulos = costeo.articulos || [];
            const gastosVarios = costeo.gastos_varios || [];
            const proveedoresConsolidado = costeo.proveedores_consolidado || [];

            const tc_usd = parseFloat(costeo.tc_usd) || 1;
            const tc_eur = parseFloat(costeo.tc_eur) || tc_usd;
            const tc_gbp = parseFloat(costeo.tc_gbp) || tc_usd;

            const monedaPrincipal = (costeo.moneda_principal || 'USD').toUpperCase();
            let tcPrincipal = tc_usd;
            if (monedaPrincipal === 'EUR') tcPrincipal = tc_eur;
            else if (monedaPrincipal === 'GBP') tcPrincipal = tc_gbp;

            const montoFactura = parseFloat(costeo.monto_factura) || 0;
            let fobActual;
            if (montoFactura > 0) {
                fobActual = montoFactura * tcPrincipal;
            } else {
                const fobActualDivisa = articulos.reduce((sum, art) => sum + (parseFloat(art.importe_total_origen) || 0), 0);
                fobActual = fobActualDivisa * tcPrincipal;
            }
            const volActual = parseFloat(costeo.volumen_m3) || 0;
            const pesoActual = parseFloat(costeo.peso_kg) || 0;

            let fobTotal = fobActual;
            let volTotal = volActual;
            let pesoTotal = pesoActual;

            const otrosProveedores = [];

            for (const p of proveedoresConsolidado) {
                let fob = parseFloat(p.fob_total) || 0;
                const monedaProv = (p.moneda || 'USD').toUpperCase();
                
                let tcProv = tc_usd;
                if (monedaProv === 'EUR') tcProv = tc_eur;
                else if (monedaProv === 'GBP') tcProv = tc_gbp;
                const fobConvertido = fob * tcProv;

                const vol = parseFloat(p.volumen_m3) || 0;
                const peso = parseFloat(p.peso_kg) || 0;
                
                fobTotal += fobConvertido;
                volTotal += vol;
                pesoTotal += peso;
                
                otrosProveedores.push({
                    nombre: p.nombre_proveedor,
                    fob_original: fob,
                    moneda: monedaProv,
                    fob_convertido: fobConvertido,
                    volumen_m3: vol,
                    peso_kg: peso
                });
            }

            const pctFob = fobTotal > 0 ? (fobActual / fobTotal) * 100 : 100;
            const pctVol = volTotal > 0 ? (volActual / volTotal) * 100 : 0;
            const pctPeso = pesoTotal > 0 ? (pesoActual / pesoTotal) * 100 : 0;

            let totalGastosAProrratear = 0;
            for (const g of gastosVarios) {
                totalGastosAProrratear += parseFloat(g.monto_ars) || 0;
            }

            return {
                es_consolidado: true,
                proveedor_actual: {
                    nombre: costeo.proveedor,
                    fob: fobActual,
                    volumen_m3: volActual,
                    peso_kg: pesoActual
                },
                otros_proveedores: otrosProveedores,
                totales: {
                    fob: fobTotal,
                    volumen_m3: volTotal,
                    peso_kg: pesoTotal
                },
                comparativo_metodos: {
                    por_fob: {
                        participacion: pctFob.toFixed(2),
                        gastos_estimados: (totalGastosAProrratear * pctFob / 100).toFixed(2)
                    },
                    por_volumen: {
                        participacion: pctVol.toFixed(2),
                        gastos_estimados: (totalGastosAProrratear * pctVol / 100).toFixed(2)
                    },
                    por_peso: {
                        participacion: pctPeso.toFixed(2),
                        gastos_estimados: (totalGastosAProrratear * pctPeso / 100).toFixed(2)
                    }
                },
                gastos: {
                    total_a_prorratear: totalGastosAProrratear.toFixed(2)
                }
            };

        } catch (error) {
            console.error('Error en preview:', error);
            throw error;
        }
    }
}

module.exports = CalculosService;